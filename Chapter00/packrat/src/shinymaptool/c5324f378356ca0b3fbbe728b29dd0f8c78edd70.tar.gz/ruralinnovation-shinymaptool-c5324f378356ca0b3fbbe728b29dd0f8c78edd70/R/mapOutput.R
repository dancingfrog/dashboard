#' Title
#'
#' @import shiny
#' @import htmltools
#'
#' @param map_id HTMLElement id
#'
#' @return
#' @export
#' @examples
#' mapOutput("map-demo")
#'

mapOutput <- function (map_id) {
  print(sprintf("Hello, %s!", map_id))
  print(sprintf("... from dir %s", getwd()))
  print(list.files(getwd()))
  src <- c(file = system.file("www", package = "shinymaptool", mustWork = TRUE))
  print(sprintf("... w/ www dir %s", src))

  el <- tags$div(
    id = map_id,
    class = "geocontainer shiny-map-tool",
    div(id = paste0(map_id, "-map")),
    HTML('<canvas id="deck-canvas"></canvas>'),
    div(id = "svelte")
  )

  # get full path
  #path <- normalizePath("assets")
  #path <- normalizePath("www")
  path <- normalizePath(src)

  deps <- list(
    htmltools::htmlDependency(
      name = "mapTool",
      version = "1.0",
      src = c(file = path),
      script = c(
        #"bootstrap/bootstrap.min.js",
        #"count-up/countUp.js",
        #"carto/carto-vl.min.js",
        #"@deck.gl/dist.min.js",
        #"@deck.gl/carto/dist.min.js",
        #"mapbox/mapbox-gl.js",
        #"turf/turf.min.js",
        "bundle.js"
      ),
      stylesheet = c(
        "styles.css",
        "bundle.css"
      )
    )
  )

  htmltools::attachDependencies(el, deps)
}
