#' Title
#'
#' @param title map application title
#' @param help_doc href link to app documentation
#' @param map_id HTMLElement id for app container div
#' @param geo_geom GeoJSON FeatureCollection
#' @param geo_table = data platform user, api key, url and table name (e.g. Carto)
#' @param geo_id_label single string; column name of unique id's
#' @param geo_ids character vector of id value
#' @param geo_params list of additional selection/filter criteria as key/type pairs
#' @param geo_values list of values matching each geo_param key/type pair: name = key^
#' @param geo_style list of simple style paramas, like color, size, opacity, etc.; ex. color = "#ef47ff"
#'
#' @return list
#' @export
#' @examples
#' mapTool(
#'    title = "Map Demo",
#'    map_id = "my-map",
#'    geo_geom = list(),
#'    geo_table = list(),
#'    geo_id_label = "geoid",
#'    geo_ids = c("47001"),
#'    geo_params = list(
#'        crude_rate = "numeric"
#'    ),
#'    geo_values = list(
#'        crude_rate = c(1, 200)
#'    ),
#'    geo_style = list()
#' )
#'

mapTool <- function(title, help_doc = "#", map_id = "my-map", geo_geom = list(), geo_table = list(), geo_id_label = "geoid", geo_ids = character(0), geo_params = list(), geo_values = list(), geo_style = list()){

  render_list <- list(
    title = title, # map application title
    help_doc = help_doc, # href link to app documentation
    map_id = map_id, # HTMLElement id for app container div
    geo_geom = geo_geom, # GeoJSON FeatureCollection
    geo_table = geo_table, # data platform user, api key and table name (e.g. Carto)
    geo_id_label = geo_id_label, # single string; column name for unique id's
    geo_ids = geo_ids, # character vector of id value
    geo_params = geo_params, # list of additional selection/filter criteria as key/type pairs
    geo_values = geo_values, # list of values matching each geo_param key/type pair: name = key^
    geo_style =  geo_style # list of simple style paramas, like color, size, opacity, etc.; ex. color = "#ef47ff"
  )

  print("Rendering with map tool params: ")
  print(names(sapply(render_list, function(l) { if (typeof(l) == "list") print(names(l)) else print(l) })))

  render_list
}

#' Title
#'
#' @import shiny
#'
#' @param expr code block containing mapTool() call with params
#' @param env optional
#' @param quoted optional
#'
#' @return
#' @export
#' @examples
#' renderMapTool({
#'   mapTool(
#'     title = "Map Demo",
#'     help_doc = "https://docs.google.com/document/d/2345opu3j4i5o2p345u234p45E",
#'     map_id = "my-map",
#'     geo_geom = list(),
#'     geo_table = list(),
#'     geo_id_label = "geoid",
#'     geo_ids = c("47001"),
#'     geo_params = list(
#'        crude_rate = "numeric"
#'     ),
#'     geo_values = list(
#'        crude_rate = c(1, 200)
#'     ),
##'    geo_style = list()
#'   )
#' })

renderMapTool <- function(expr, env = parent.frame(), quoted = FALSE) {
  # Convert the expression + environment into a function
  render_func <- shiny::exprToFunction(expr, env, quoted)

  return(render_func)
}
