import LayersPass from './layers-pass';

export default class DrawLayersPass extends LayersPass {}
