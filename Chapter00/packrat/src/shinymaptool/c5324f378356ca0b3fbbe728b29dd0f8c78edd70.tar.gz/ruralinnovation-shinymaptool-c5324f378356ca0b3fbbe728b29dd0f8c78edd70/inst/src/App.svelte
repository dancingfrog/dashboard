<script>
    import carto from "@carto/carto-vl";
    import CartoMapbox from "./map/carto-mapbox";
    import { onMount } from "svelte";
    import turf from "@turf/turf";
    // import { test, test1, test2, test3, test4 } from "./map/test-geos";

    window.addEventListener("message", (event) => {
        console.log("MESSAGE FROM ", event.origin);
        if (event.origin !== "http://127.0.0.1:4321" &&
            event.origin.match(/https\:\/\/localhost/) === null &&
            event.origin.match(/https\:\/\/.*airtableblocks\.com/) === null &&
            event.origin.match(/https\:\/\/.*ruralinnovation\.shinyapps\.io/) === null) {

            return;

        } else {
            console.log(event.data);
            if (event.data.match(/selectedGeo/) !== null) {
                force_jump = true;
                window.location.hash = event.data;
            }
        }
        // ...
    }, false);

    export let VERSION = '0.0.0'

    export let force_jump = false;
    export let map;
    export let geo_srid = 4326;
    export let fips = "";
    export let county = "";
    export let name = "";
    export let state = "";
    export let selection = {};
    export let selected_color = "#C80E38";
    export let show_geo_info = true;
    export let simplification_tolerance = 0.05;
    export let tool_title = "";
    export let help_doc = "";

    export const INITIAL_VIEW_STATE = {
        longitude: -87.06166019375802,
        latitude: 36.306272992841286,
        zoom: 12,
        pitch: 5,
        bearing: 0
    };

    let legend_layers = [];
    const toggle_layers = {};

    let map_bounds = [
        [ -87.06166019375802, 36.306272992841286 ],
        [ -73.45134669532756, 35.74110771792324 ]
    ];

    let basemaps = [
        // <!-- See a list of Mapbox-hosted public styles at -->
        // <!-- https://docs.mapbox.com/api/maps/styles/#mapbox-styles -->
        { id:"satellite-v9", name:"rtoggle", value:"satellite", label:"Satellite Map" },
        { id:"streets-v11", name:"rtoggle", value:"streets", label:"Street Map" }
    ];
    let basemap = basemaps[(basemaps.length - 2)].id;

    let changeBasemap = (basemap) => {
        console.log("Set basemap", basemap)
    };
    $: changeBasemap(basemap);

    const carto_table_info = {};
    const carto_table_labels = {};
    const carto_table_styles = {};

    let deckGLJump = null;

    let filter_by_selection = true;

    let geom_rendering = false;

    let selected_feature_props = [];
    let selected_feature = {};
    let selected_table_id = "";

    let save_buffer = 1;
    let st_buffer = 1;
    let buffer = true;

    let notes = "";

    const toggleFilter = (evt, toggle) => {
        if ('checked' in evt.target && !!toggle) {
            console.log(evt.target);
            filter_by_selection = !!evt.target.checked;
        }

        // legend_layers.forEach(table_id => {
        //     if (!!toggle_layers[table_id].checked) try {
        //         toggle_layers[table_id].turn_off();
        //     } finally {
        //         if (!('last_triggered' in toggle_layers) || ((new Date()).getTime() - toggle_layers[table_id].last_triggered) > 255) {
        //             setTimeout(toggle_layers[table_id].turn_on, 233);
        //         }
        //     }
        // });
    };

    const toggleLayer = (evt, table_id) => {
        toggle_layers[table_id].checked = evt.target.checked;
        if (!!toggle_layers[table_id].checked) {
            if (!('last_triggered' in toggle_layers) || ((new Date()).getTime() - toggle_layers[table_id].last_triggered) > 255) {
                toggle_layers[table_id].turn_on();
            } else {
                console.log(`Last triggered ${(new Date()).getTime()} - ${toggle_layers[table_id].last_triggered} = ${((new Date()).getTime() - toggle_layers[table_id].last_triggered)} seconds ago`, )
            }
        } else {
            toggle_layers[table_id].turn_off();
            document.getElementById(`legend-${table_id}-colors`).innerHTML=`
                                <div class="CDB-LoaderIcon CDB-LoaderIcon--big svelte-cs19r4" style="margin-left: 40px;">
                                    <svg class="CDB-LoaderIcon-spinner svelte-cs19r4" style="width: 25px;height: 25px;" viewBox="0 0 50 50">
                                        <circle class="CDB-LoaderIcon-path svelte-cs19r4" cx="25" cy="25" fill="none" r="20"></circle>
                                    </svg>
                                </div>
`;
            if (selected_table_id === table_id) selected_table_id = "";
        }
    };

    const shinyMapToolBinding = (!!window && !!window['Shiny']) ?
        new Shiny.OutputBinding() :
        (function () {}).constructor;

    shinyMapToolBinding.constructor.prototype.find =
        function(scope) /*: HTMLCollection */ {
            console.log('SHINY MAP TOOL v' + VERSION);
            console.log("scope: ", scope.length);

            // window.alert("REGISTERED");

            if (!!scope && scope.length > 0) {
                try {
                    const found = scope[0].getElementsByClassName('shiny-map-tool')
                    if (found != null && found.length > 0) return found;
                } catch(e) {
                    console.error(e)
                }
            }

            return document.body.getElementsByClassName('shiny-map-tool');
            // return $(scope).find(".shiny-map-tool");
        };

    shinyMapToolBinding.constructor.prototype.getId =
        function(el) {
            return el['data-input-id'] || el.id;
        };

    shinyMapToolBinding.constructor.prototype.renderValue =
        function(el, data) {
            console.log('el: ', el);
            console.log('data: ', data);
            // console.log('data geo_geom: ', data.geo_geom);
            // console.log('params: ', data.geo_params);

            const map_id = data.map_id;

            if ('help_doc' in data) {
                help_doc = data['help_doc'];
            }

            if ('title' in data) {
                const title_template = `
            <a href="#" data-toggle="tab" data-value="${data.title}">
                <i class=" cori-risi cori-logo" role="presentation" aria-label=" icon"></i>
                <i class=" cori-risi risi-logo" role="presentation" aria-label=" icon"></i>
                ${data.title}
            </a>
`
                console.log(title_template);

                tool_title = data.title;

                if (document.getElementsByClassName('navbar-static-top').length > 0 &&
                    document.getElementsByClassName('navbar-custom-menu').length > 0 &&
                    !!document.getElementById('tool-title')
                ) {
                    document.getElementsByClassName('navbar-static-top')[0]
                        .insertBefore(document.getElementById('tool-title'), document.getElementsByClassName('navbar-custom-menu')[0]);
                }
            }

            // background color
            // el.style.backgroundColor = data.color;
            if (!!data.geo_style && 'color' in data.geo_style) {
                selected_color = data.geo_style.color;
            }

            if (!map) {

                if ('geo_table' in data) {
                    console.log(data['geo_table']);

                    if ('hide_geo_info' in data['geo_table'] && !!data['geo_table']['hide_geo_info']) {
                        show_geo_info = false;
                    }

                    if ('mapbox' in data['geo_table']) {
                        const update_basemaps = basemaps.concat([]);

                        if ('init' in data['geo_table']['mapbox']) {
                            const init_view_state = data['geo_table']['mapbox']['init'];
                            for (const i in init_view_state) {
                                if (init_view_state.hasOwnProperty(i)) {
                                    INITIAL_VIEW_STATE[i] = init_view_state[i];
                                }
                            }
                            console.log('INITIAL_VIEW_STATE: ', INITIAL_VIEW_STATE);

                        } else if (!!data.geo_geom && 'features' in data.geo_geom && data.geo_geom.features.length > 0) {
                            if ('properties' in data.geo_geom.features[0] &&
                                'lat' in data.geo_geom.features[0].properties &&
                                'lon' in data.geo_geom.features[0].properties) {
                                INITIAL_VIEW_STATE['longitude'] = data.geo_geom.features[0].properties['lon'];
                                INITIAL_VIEW_STATE['latitude'] = data.geo_geom.features[0].properties['lat'];
                            }
                        }

                        try {
                            for (const b in data['geo_table']['mapbox']['basemaps']) {
                                if ((data['geo_table']['mapbox']['basemaps']).hasOwnProperty(b)) {
                                    update_basemaps.unshift(
                                        {
                                            id: data['geo_table']['mapbox']['basemaps'][b],
                                            name: "rtoggle",
                                            value: b.toString(),
                                            label: b.toString()
                                        });
                                }
                            }

                        } finally {
                            basemaps = update_basemaps;
                            basemap = basemaps[0].id;
                            console.log(basemap);
                        }
                    }

                    map = window['map'] =
                        new CartoMapbox(
                            el,
                            data['geo_table']['mapbox']['apiKey'],
                            map_id,
                            map_bounds,
                            INITIAL_VIEW_STATE,
                            basemap
                        ).getMap();

                } else {
                    map = window['map'] =
                        new CartoMapbox(
                            el,
                            "pk.eyJ1IjoicnVyYWxpbm5vIiwiYSI6ImNqeHl0cW0xODBlMm0zY2x0dXltYzRuazUifQ.zZBovoCHzLIW0wCZveEKzA",
                            map_id,
                            map_bounds,
                            INITIAL_VIEW_STATE,
                            basemap
                        ).getMap();
                }

                changeBasemap = (basemapId) => {
                    console.log(basemapId, basemaps);
                    map.changeBasemap(basemapId);
                };
            }

            // console.log(map);

            if (!!map) {

                const feature_fips = [];
                const geoid_label = ('geo_id_label' in data) ?
                    data['geo_id_label'] :
                    'geoid_co';

                if (!!data.geo_geom && 'features' in data.geo_geom && data.geo_geom.features.length > 0) {
                    if ('srid' in data.geo_geom) {
                        geo_srid = data.geo_geom.srid;
                    }

                    for (const g in data.geo_geom) {
                        if (g === 'features') for (const f in data.geo_geom.features) {
                            const feature = data.geo_geom.features[f];
                            if ('properties' in feature && geoid_label in feature.properties) {
                                fips = feature.properties[geoid_label];
                                feature_fips.push(fips)
                            } else if ('properties' in feature  && 'geoid' in feature.properties) {
                                fips = feature.properties['geoid'];
                                feature_fips.push(fips)
                            } else if ('properties' in feature  && 'geoid_co' in feature.properties) {
                                fips = feature.properties['geoid_co'];
                                feature_fips.push(fips)
                            } else if ('properties' in feature  && 'fips' in feature.properties) {
                                fips = feature.properties['fips'];
                                feature_fips.push(fips)
                            }

                            if ('properties' in feature) {
                                const cims_id = `${(
                                    ("name_co" in feature.properties)?
                                        feature.properties.name_co :
                                        ("name_st" in feature.properties)?
                                            feature.properties.name_st :
                                            ("name" in feature.properties)?
                                                feature.properties.name :
                                                feature.properties[Object.getOwnPropertyNames(feature.properties)[0]])
                                    .toString().replace(new RegExp(/;/, 'ig'), ' / ')
                                }`;
                                console.log(cims_id);
                                selection['props'] =  [];
                                selection['properties'] = {};

                                if ('fields' in data.geo_geom) for (const p in data.geo_geom['fields']) {
                                    if (data.geo_geom['fields'].hasOwnProperty(p) && feature.properties.hasOwnProperty(p)) {
                                        selection.props.push(data.geo_geom['fields'][p]['label']);
                                        selection.properties[data.geo_geom['fields'][p]['label']] = feature.properties[p];
                                        console.log(data.geo_geom['fields'][p]['label'], selection.properties[data.geo_geom['fields'][p]['label']]);
                                    }

                                } else for (const p in feature.properties) {
                                    if (feature.properties.hasOwnProperty(p)) {
                                        selection.props.push(p);
                                        selection.properties[p] = feature.properties[p];
                                    }
                                }

                                if ('fields' in data.geo_geom) console.log(selection.properties);

                                selection['id'] = cims_id;
                            }

                        }

                    }

                    if (!geom_rendering) {
                        // TODO: for (g in geom) ... remove
                        const geom = data.geo_geom;
                        // // DEBUG:
                        // for (const feature of geom['features']) {
                        //     console.log("INPUT GEOMETRY: ", feature.geometry)
                        //     feature.geometry = turf.buffer(turf.simplify(feature, { highQuality: true, tolerance: simplification_tolerance }), st_buffer * 1609, {units: 'meters'}).geometry;
                        //     console.log("OUTPUT GEOMETRY: ", feature.geometry)
                        // }
                        const geoms = map.getGeomDataFeatures();
                        const update_features = [];
                        for (const g in geoms) {
                            console.log(g);
                            // Discard geometry if not include in Shiny app selection
                            if (feature_fips.filter(f => f.toString() === g.toString()) < 1) {
                                console.log("Removing geom ", geoms[g]);
                                delete geoms[g];

                            } else if ('geometry' in geoms[g]) {
                                update_features.push(geoms[g])
                            }
                        }

                        map.setGeomDataFeatures(update_features);

                        map.addGeoJSONLayer('geo_geom', data.geo_geom, `
color: rgba(255, 255, 255, 0.025)
strokeColor: ${(selected_color || '#C80E38')}
strokeWidth: 4
width: 4`,
                            null,
                            deckGLJump,
                            force_jump);

                        setTimeout(t => { geom_rendering = false }, 533);
                    }

                    geom_rendering = true;

                    filter_by_selection = true;

                } else {
                    console.log("Removing geo_geom layer");

                    fips = "";

                    map.setGeomDataFeatures([]);

                    delete selection['id'];

                    map.removeLayerWithId('geo_geom');

                    filter_by_selection = false;
                }

                if ('geo_table' in data && 'carto' in data['geo_table']) {

                    console.log("INITIALIZED");

                    if ('geo_params' in data) {

                        const geo_ids = [];

                        if ('geo_ids' in data && (data['geo_ids'] != null)) {

                            if (!!data['geo_ids'] && data['geo_ids'].toString().match(/^\d+$/) !== null) {
                                geo_ids.push(data['geo_ids']); // single

                            } else {
                                for (const g in data['geo_ids']) {
                                    if (data['geo_ids'][g].toString().match(/^\d+$/) !== null) {
                                        geo_ids.push(data['geo_ids'][g]);
                                    }
                                }
                            }

                            if (geo_ids.length < 1) {
                                feature_fips.forEach(f => {
                                    if (geo_ids.filter(g => g === f).length < 1) geo_ids.push(f)
                                });
                            }

                            const new_location = window.location.toString().substring(0, window.location.toString().indexOf('?')) +
                                `?geoids=${geo_ids.join(',')}`;

                            console.log('URL derived from Shiny geo selection: ', new_location, geo_ids);

                            window.history.replaceState({} , document.title, new_location.toString());

                            console.log('SELECTED GEOIDs:', geo_ids);
                            fetchCartoLayer(data['geo_table']['carto'], data['geo_params'], data['geo_values'], geo_ids, data['geo_id_label'], data['geo_geom'], data['geo_style']);

                        } else if ('geo_geom' in data && (data.geo_geom != null && 'features' in data.geo_geom && data.geo_geom['features'].length > 0)) {
                            data.geo_geom['features'].forEach(g => {
                                console.log(g);

                                if (geoid_label in g.properties) {
                                    geo_ids.push(g.properties[geoid_label]);
                                } else if ('geoid' in g.properties) {
                                    geo_ids.push(g.properties['geoid']);
                                }  else if ('geoid_co' in g.properties) {
                                    geo_ids.push(g.properties['geoid']);
                                }  if ('geoid_pl' in g.properties) {
                                    geo_ids.push(g.properties['geoid']);
                                } else if ('fips' in g.properties) {
                                    geo_ids.push(g.properties['fips']);
                                }
                            });

                            if (geo_ids.length < 1) {
                                feature_fips.forEach(f => {
                                    if (geo_ids.filter(g => g === f).length < 1) geo_ids.push(f)
                                });
                            }

                            const new_location = window.location.toString().substring(0, window.location.toString().indexOf('?')) +
                                `?geoids=${geo_ids.join(',')}`;

                            console.log(new_location, geo_ids);

                            window.history.replaceState({} , document.title, new_location.toString());

                            console.log('SELECTED GEOIDs:', geo_ids);
                            fetchCartoLayer(data['geo_table']['carto'], data['geo_params'], data['geo_values'], geo_ids, data['geo_id_label'], data['geo_geom'], data['geo_style']);

                        } else {
                            console.log("Removing all geo_geom!");

                            map.setGeomDataFeatures([]);

                            map.removeLayerWithId('geo_geom');

                            // Clear geo_param layers from map
                            for (const l in map.layersById) {
                                console.log(`Remove ${l}`);
                                map.removeLayerWithId(l);
                            }

                            fetchCartoLayer(data['geo_table']['carto'], data['geo_params'], data['geo_values'], null, null, null, data['geo_style']);
                        }
                    }
                }

            }

            setTimeout(hideLoader, 2533);
        };

    function fetchCartoLayer (carto_tables, geo_params, geo_values, geo_ids, geo_id_label, geo_geom, geo_style) { // value_range = [ 1, 2 ], type = 'subsidy_awards
        if ('apiKey' in carto_tables && 'username' in carto_tables && 'serverURL' in carto_tables && 'table' in carto_tables) {
            const auth = {
                apiKey: carto_tables['apiKey'],
                username: carto_tables['username']
            };

            const config = {
                serverURL: carto_tables['serverURL']
            };

            const tables = carto_tables['table'];

            const geom = map.getGeomDataFeatures();
            const features = [];
            for (const g in geom) {
                if ('geometry' in geom[g]) {
                    features.push(geom[g])
                }
            }

            console.log(features);

            const all_layer_toggles = [];
            let layerIndex = 0;

            for (const t in tables) if (tables.hasOwnProperty(t)) {
                const currentLayerIndex = layerIndex;
                const delay = 2533;
                const table_idx = t;
                const table = tables[t];

                console.log(`TABLE_ID: ${table}`);

                if ('table_info' in carto_tables && !!carto_tables['table_info'][table_idx]) {
                    carto_table_info[table] = carto_tables['table_info'][table_idx]
                } else {
                    carto_table_info[table] = "";
                }

                if ('table_labels' in carto_tables && !!carto_tables['table_labels'][table_idx]) {
                    carto_table_labels[table] = carto_tables['table_labels'][table_idx]
                } else {
                    carto_table_labels[table] = table;
                }

                if ('table_styles' in carto_tables && !!carto_tables['table_styles'][table_idx]) {
                    carto_table_styles[table] = (carto_tables['table_styles'][table_idx].match(/@style/) !== null) ? `
${
                        carto_tables['table_styles'][table_idx] // assume a single @style rule was provided
}` : `
${
                        carto_tables['table_styles'][table_idx]
                            .match(/([\w|\s]+\:\s?[\w|\(|\#|\.|\|'|\:|\/|\_)]+(\s?,\s?[\w|\(|\#|\.|\)]*)*[\s\S]?)/gi)
                            .join("\n")
}`;
                } else {
                    carto_table_styles[table] = "";
                }

                let viz1 = "";
//(carto_table_styles[table])? `
//       width: 15
//       symbol: star
//       symbolPlacement: placement(0, 0)
// ` : // `
// markerWidth: 28
// markerFill: #FF0
// markerFillOpacity: 1
// markerAllowOverlap: true
// markerLineWidth: 4
// markerLineColor: #636363
// markerLineOpacity: 1
// /*https://commons.wikimedia.org/wiki/File:University_hat_icon.svg*/
// /*Leon Rische https://thenounproject.com/l3kn, CC BY 3.0 <https://creativecommons.org/licenses/by/3.0>, via Wikimedia Commons*/
// symbol: image('https://coriassets.s3.amazonaws.com/University_hat_icon.svg')
// symbol: image('https://libs.cartocdn.com/carto-vl/assets/walmart.svg')
// ` : "";

                const layers = legend_layers;
                if (legend_layers.filter(l => l === table).length < 1) {
                    // TODO: Get label for each table
                    layers.push(table);
                    toggle_layers[table] = {};
                    toggle_layers[table].checked = false;
                    all_layer_toggles.push(toggle_layers[table].checked);
                }

                // console.log('legend_layers: ', legend_layers);
                // console.log('toggle_layers: ', toggle_layers);

                legend_layers = layers;

                toggle_layers[table].turn_on = function () {
                    toggle_layers[table].last_triggered = (new Date()).getTime();

                    const field_names = [];
                    const field_labels = [];
                    const field_types = [];
                    let county_label = "";
                    let fips_label = "";
                    let name_label = "";
                    let metrics = [];
                    // [
                    //     {
                    //         name: "<metric>",
                    //         type: "<type>",
                    //         value_range: "<value(s)>"
                    //     }
                    // ]

                    let no_metrics = true;

                    console.log('geo_params: ', geo_params);

                    if (!!geo_params) for (const p in geo_params) {
                        // console.log(`${table}\.(.+)`, p);
                        if (typeof geo_params[p] === 'object' && 'label' in geo_params[p] && 'type' in geo_params[p]) {
                            // console.log(p, geo_params[p]);
                            const field_match = p.toString().match(new RegExp(`${table}\.(.+)`));
                            if (field_match != null && field_match.length > 1) {
                                console.log(p, geo_params[p]['type']);
                                field_names.push(field_match[1]);
                                field_labels.push(geo_params[p]['label']);
                                field_types.push(geo_params[p]['type']);
                                if (field_match[1].match(/^geoid/i) != null ||
                                    field_match[1].match(/^fip/i) != null) {
                                    console.log('FIPS LABEL: ', field_match[1]);
                                    fips_label = field_match[1];
                                }
                                if (//field_match[1].match(/^namelsad/i) != null ||
                                    !name_label && (
                                        field_match[1].match(/^name_co/i) != null
                                )) {
                                    console.log('COUNTY LABEL: ', field_match[1]);
                                    county_label = field_match[1];
                                }
                                if (field_match[1].match(/acp_name/i) != null ||
                                    field_match[1].match(/instnm/i) != null ||
                                    field_match[1].match(/subsidy_recipient/i) != null ||
                                    !name_label && (
                                        field_match[1].match(/name/i) != null && // contains "name", but not...
                                        field_match[1].match(/name_cbsa/i) == null &&
                                        field_match[1].match(/name_co/i) == null &&
                                        field_match[1].match(/name_st/i) == null &&
                                        field_match[1].match(/cbsa_name/i) == null &&
                                        field_match[1].match(/co_name/i) == null &&
                                        field_match[1].match(/st_name/i) == null &&
                                        field_match[1].match(/namelsad/i) == null
                                )) {
                                    console.log('NAME LABEL: ', field_match[1]);
                                    name_label = field_match[1];
                                }
                            }
                        } else {
                            // console.log(p, geo_params[p]);
                            const field_match = p.toString().match(new RegExp(`${table}\.(.+)`));
                            if (field_match != null && field_match.length > 1) {
                                console.log(p, field_match[1]);
                                field_names.push(field_match[1]);
                                field_labels.push(field_match[1]);
                                field_types.push(geo_params[p].toString());
                                if (field_match[1].match(/^geoid/i) != null ||
                                    field_match[1].match(/^fip/i) != null) {
                                    console.log('FIPS LABEL: ', field_match[1]);
                                    fips_label = field_match[1];
                                }
                                if (//field_match[1].match(/^namelsad/i) != null ||
                                    !name_label && (
                                        field_match[1].match(/^name_co/i) != null
                                )) {
                                    console.log('COUNTY LABEL: ', field_match[1]);
                                    county_label = field_match[1];
                                }
                                if (field_match[1].match(/acp_name/i) != null ||
                                    field_match[1].match(/instnm/i) != null ||
                                    field_match[1].match(/subsidy_recipient/i) != null ||
                                    !name_label && (
                                        field_match[1].match(/^name/i) != null
                                )) {
                                    console.log('NAME LABEL: ', field_match[1]);
                                    name_label = field_match[1];
                                }
                            }
                        }
                    }

                    if (!!geo_id_label && field_names.filter(f => f === geo_id_label).length > 0) {
                        toggle_layers[table].buffer = false;
                        buffer = false;

                        if (!!fips && !!selection['id'] && !!show_geo_info) {
                            save_buffer = st_buffer;
                            st_buffer = 1;

                            // // Redraw layers with smaller buffer
                            // legend_layers.forEach(table_id => {
                            //     if (table !== table_id && table.match(table_id) === null && !!toggle_layers[table_id].checked && !!toggle_layers[table_id].buffer) try {
                            //         toggle_layers[table_id].turn_off();
                            //     } finally {
                            //         if (!('last_triggered' in toggle_layers) || ((new Date()).getTime() - toggle_layers[table_id].last_triggered) > 255) {
                            //             setTimeout(toggle_layers[table_id].turn_on, 233);
                            //         }
                            //     }
                            // });
                        }

                    } else {
                        toggle_layers[table].buffer = true;
                    }

                    if (!!geo_values) {

                        let style_ramp = (!!carto_table_styles[table] && carto_table_styles[table].match(/@style:\s?opacity\((.+),\s? [0-9|\.]+\)/) !== null) ?
                            carto_table_styles[table].match(/@style:\s?opacity\((.+),\s? [0-9|\.]+\)/)[1] :
                            "";

                        let used_geom_web = false;

                        // Conditional left join on broadband notes
                        let left_join = false; // (table.match(/(?:county_ilecs_geo|incumbent_electric_providers_geo)/) !== null) ?
                            // " LEFT JOIN " + (
                            //     (table.match(/county_ilecs_geo/) !== null)?
                            //         "  (SELECT * FROM ayerstndataairtableviazapier_ilecs) AS carto_notes ON carto_table.ilec_name = carto_notes.co_name " :
                            //         "  (SELECT * FROM ayerstndataairtableviazapier_electricutilities) AS carto_notes ON carto_table.utility_name = carto_notes.utility_name "
                            // ):
                            // "";

                        let sql_query = "select " + ((
                                (field_names.length > 0) ?
                                    field_names.filter(f => {
                                        if (f.match(/geom/) !== null) {
                                            if (field_names.filter(n => n === "the_geom_webmercator_webmercator").length > 0 ) {
                                                if (f === "the_geom_webmercator") {
                                                    // We will map the_geom to ST_Buffer
                                                    used_geom_web = true;
                                                    return true;

                                                } else return false;

                                            } else {
                                                // the_geom_webmercator does not exist
                                                return true;
                                            }

                                        } else return true;

                                    }).map(f => {
                                        if (f.match(/geom/) === true && !!used_geom_web) {
                                            return `carto_table.the_geom_webmercator`;

                                        } else return `carto_table.${f}`;
                                    }).join(',') :
                                    "*") + ((!!left_join) ? "," +
                                    "carto_notes.notes as notes" //," +
                                    // "carto_notes.sac as sac," +
                                    // "carto_notes.hoco as hoco," +
                                    // "carto_notes.regtype as regtype," +
                                    // "carto_notes.ocn as ocn," +
                                    // "carto_notes.ocnst as ocnst," +
                                    // "carto_notes.broadband_data as broadband_data," +
                                    // "carto_notes.ayers_from_broadband_cims_from_broadband_data_ as ayers_from_broadband_cims_from_broadband_data_"
                                    : ""
                            )
                        ) + ` from "${auth['username']}".${table} as carto_table ` + (
                            (!!left_join) ?
                                left_join :
                                ""
                        );

                        console.log('INIT SQL: ', sql_query);

                        const categorical_palettes = [
                            "ANTIQUE",
                            "BOLD",
                            "PASTEL",
                            "PRISM",
                            "SAFE",
                            "VIVID"
                        ];

                        const gradient_palettes = [
                            "BURGYL", // "REDOR",
                            "BLUYL", // "BLUGRN",
                            "ORYEL", // "PINKYL",
                            "EMRLD", // "DARKMINT",
                            "PURP", // "PURPOR",
                            "SUNSETDARK", // "SUNSET"
                        ];

                        console.log(table, 'geo_values: ', geo_values);
                        for (const m in geo_values) if (geo_values.hasOwnProperty(m) &&
                            m.match(new RegExp(`${table}\.(.+)`)) !== null // match table name
                        ) {
                            const value_range = geo_values[m];
                            let metric_index = 0;
                            const metric_names = field_names.filter((n, i) => {
                                console.log(n, m.match(new RegExp(`${table}\.(.+)`))[1]);
                                if (n.match(m.match(new RegExp(`${table}\.(.+)`))[1]) !== null) {
                                    metric_index = i;
                                    return true;
                                }
                            });
                            console.log(metric_names);

                            if (metric_names.length > 0) {
                                console.log(m, value_range, metric_names);
                                const metric_name = field_names[metric_index];
                                const type = field_types[metric_index];
                                const metric = {
                                    name: metric_name,
                                    type: type,
                                    value_range: value_range
                                }
                                const palette_idx = Math.round(Math.random() * metric_index * 10) % 6;
                                metrics.push(metric);
                                console.log(metric_name, metric, palette_idx);

                                no_metrics = false;

                                // // `ramp(linear($${metric},1,70), [gold, ${selected_color}])`
                                // // `ramp($${metric}, [gold, ${selected_color}])`
                                // // ramp(buckets($winner, ["Conservative Party", "Labour Party"]), [royalblue, crimson])
                                style_ramp = style_ramp || (
                                    (type === "double" || type === "integer") ?
                                        `ramp($${metric_name}, ${(!!geo_style && 'gradient' in geo_style) ? geo_style['gradient'] : gradient_palettes[palette_idx]})` :
                                        `ramp(top($${metric_name}, 15), ${(!!geo_style && 'categorical' in geo_style) ? geo_style['categorical'] : categorical_palettes[palette_idx]}, rgba(${convertColor(selected_color || '#C80E38')}, ${(!!geo_style && 'opacity' in geo_style) ? geo_style['opacity'] : 0.25}))`
                                    // `ramp(top($${metric_name}, 4), [darkorange,darkviolet,darkturquoise], ${selected_color})`
                                    // `ramp(buckets($tier ['Above Baseline', 'Gigabit'])), ${carto_vl_palettes[metric_index]})`
                                );

                                if (!Array.isArray(value_range) || (typeof value_range[0] != 'undefined')) {
                                    sql_query = (
                                        (sql_query.match(/where/) === null) ? sql_query + " where " : sql_query + " and "
                                    ) + (
                                        (type === "double" || type === "integer") ?
                                            (!Array.isArray(value_range) || value_range.length === 1) ?
                                                ` ${value_range[0] || value_range} < carto_table.${metric_name} ` :
                                                (Array.isArray(value_range) && value_range.length > 1) ?
                                                    `( ${value_range[0]} < carto_table.${metric_name} and carto_table.${metric_name} < ${value_range[(value_range.length - 1)]} )` :
                                                    ' ' :
                                            // (type === "character") ?
                                            (!Array.isArray(value_range) || (value_range.length === 1 && typeof value_range[0] != 'undefined')) ?
                                                ` carto_table.${metric_name} ilike '${value_range}' ` :
                                                (Array.isArray(value_range) && value_range.length > 1 && typeof value_range[0] != 'undefined') ?
                                                    `( carto_table.${metric_name} ilike '` + value_range.join(`' or carto_table.${metric_name} ilike '`) + `' )` :
                                                    ' '
                                    );
                                }

                                console.log(value_range[0]);

                                console.log('SQL: ', sql_query);

                                console.log(`TABLE_LABEL: ${carto_table_labels[table]}`);
                                console.log(`TABLE_STYLE: ${carto_table_styles[table]}`);

                                viz1 = viz1 || (
                                    (!left_join) &&
                                    (!!fips_label && fips_label.length > 0) &&
                                    (!!county_label && county_label.length > 0) &&
                                    (!!name_label && name_label.length > 0) ? `
@currentFeatures: viewportCount()
@${name_label}: $${name_label}` + ((metric_name !== name_label) ? `
@${metric_name}: $${metric_name}` : ``) + `
@${fips_label}:  $${fips_label}
@${county_label}: $${county_label}` + field_names.map((field, i, a) => {
                                        console.log("Map VIZ to field: ", field);
                                        return (
                                            field.match(/carto/) === null &&
                                            field.match(/geom/) === null &&
                                            field.match(name_label) === null &&
                                            field.match(metric_name) === null &&
                                            field.match(fips_label) === null &&
                                            field.match(county_label) === null &&
                                            field_types[i] !== 'logical'
                                        ) ? `
@${field_labels[i]}: $${field_names[i]}` : '';
                                    }).join('') + (
                                        (!!carto_table_styles[table])?
                                            carto_table_styles[table] : `
@style: opacity(${style_ramp}, ${(carto_table_styles[table]) ? 1.0 : (!!geo_style && 'opacity' in geo_style) ? geo_style['opacity'] : 0.25})`) + `
color: @style
strokeColor: ${(selected_color || '#C80E38')}
@v_features: viewportFeatures($${name_label})` :
                                    (!left_join) &&
                                    (!!name_label && name_label.length > 0) ? `
@currentFeatures: viewportCount()
@${name_label}: $${name_label}` + ((metric_name !== name_label) ? `
@${metric_name}: $${metric_name}` : ``) +
                                    field_names.map((field, i, a) => {
                                        console.log("Map VIZ to field: ", field);
                                        return (
                                            field.match(/carto/) === null &&
                                            field.match(/geom/) === null &&
                                            field.match(name_label) === null &&
                                            field.match(metric_name) === null &&
                                            field_types[i] !== 'logical'
                                        ) ? `
@${field_labels[i]}: $${field_names[i]}` : '';
                                    }).join('') + (
                                        (!!carto_table_styles[table])?
                                            carto_table_styles[table] : `
@style: opacity(${style_ramp}, ${(carto_table_styles[table]) ? 1.0 : (!!geo_style && 'opacity' in geo_style) ? geo_style['opacity'] : 0.25})`) + `
color: @style
strokeColor: ${(selected_color || '#C80E38')}
@v_features: viewportFeatures($${name_label})` : `
@currentFeatures: viewportCount()` + (
                                        (!!left_join && left_join.length > 0) ?
                                            field_names.map((field, i, a) => {
                                                return (
                                                    field.match(/carto/) === null &&
                                                    field.match(/geom/) === null &&
                                                    field_types[i] !== 'logical'
                                                ) ? `
@${field_labels[i]}: $${field_names[i]}` : '';
                                            }).join('') + `
@notes: $notes`
                                            :
                                            field_names.map((field, i, a) => {
                                                return (
                                                    field.match(/carto/) === null &&
                                                    field.match(/geom/) === null &&
                                                    field_types[i] !== 'logical'
                                                ) ? `
@${field_labels[i]}: $${field_names[i]}` : '';
                                            }).join('')
                                    ) + (
                                        (!!carto_table_styles[table])?
                                            carto_table_styles[table] : `
@style: opacity(${style_ramp}, ${(carto_table_styles[table]) ? 1.0 : (!!geo_style && 'opacity' in geo_style) ? geo_style['opacity'] : 0.25})`) + `
color: @style
strokeColor: ${(selected_color || '#C80E38')}`
                                );
                            }
                        }

                        console.log('FILTER BY GEOM: ', (!!filter_by_selection && !!features && features.length > 0));

                        // Toggle filter by selected geo
                        sql_query = (!!filter_by_selection && !!geo_id_label && field_names.filter(f => f === geo_id_label).length > 0 && !!geo_ids && geo_ids.length > 0) ?
                            `SELECT distinct(the_geom) as distinct_geom, * FROM (${sql_query}) as complex_query where ${
                                (Array.isArray(geo_ids) && geo_ids.length > 1) ?
                                    // TODO: regexp_replace(regexp_replace(regexp_replace(geoid,%20'\"',%20'',%20'gi'),%20'“',%20'',%20'gi'),%20'”',%20'',%20'gi')%20ilike%20'%2506001'
                                    geo_ids.map(f => `regexp_replace(regexp_replace(regexp_replace(${geo_id_label}, '"', '', 'gi'), '“', '', 'gi'), '”', '', 'gi') ilike '%${f}'`).join(' or ') :
                                    `regexp_replace(regexp_replace(regexp_replace(${geo_id_label}, '"', '', 'gi'), '“', '', 'gi'), '”', '', 'gi') ilike '%${geo_ids}'`
                            }` :
                            (!!filter_by_selection && !!features && features.length > 0) ?
                                `SELECT distinct(the_geom) as distinct_geom, * FROM (${sql_query}) as complex_query where ${
                                    (Array.isArray(features) && features.length > 1) ? // ST_Transform(ST_SetSRID(ST_Point(-123.365556, 48.428611),4326),3857)
                                        features.map(f => `ST_Contains(ST_SetSRID(ST_GeomFromGeoJSON('${JSON.stringify(turf.buffer(turf.simplify(f, { highQuality: true, tolerance: simplification_tolerance }), st_buffer * 1609, {units: 'meters'}).geometry)}'),${geo_srid}), ST_SetSRID(complex_query.the_geom,${geo_srid}))
                                            or ST_Intersects(ST_SetSRID(complex_query.the_geom,${geo_srid}), ST_SetSRID(ST_GeomFromGeoJSON('${JSON.stringify(turf.buffer(turf.simplify(f, { highQuality: true, tolerance: simplification_tolerance }), st_buffer * 1609, {units: 'meters'}).geometry)}'),${geo_srid}))`).join(' or ') :
                                        `ST_Contains(ST_SetSRID(ST_GeomFromGeoJSON('${JSON.stringify(turf.buffer(turf.simplify(features[0], { highQuality: true, tolerance: simplification_tolerance }), st_buffer * 1609, {units: 'meters'}).geometry)}'),${geo_srid}), ST_SetSRID(complex_query.the_geom,${geo_srid}))
                                            or ST_Intersects(ST_SetSRID(complex_query.the_geom,${geo_srid}), ST_SetSRID(ST_GeomFromGeoJSON('${JSON.stringify(turf.buffer(turf.simplify(features[0], { highQuality: true, tolerance: simplification_tolerance }), st_buffer * 1609, {units: 'meters'}).geometry)}'),${geo_srid}))`
                                }` :
                                sql_query;

                        console.log(`TABLE_`, table);
                        console.log(`TABLE_LABEL: ${carto_table_labels[table]}`);
                        console.log(`TABLE_STYLE: ${carto_table_styles[table]}`);

                        viz1 = viz1 || (
                            (!left_join) &&
                            (!!county_label && county_label.length > 0) &&
                            (!!fips_label && fips_label.length > 0) &&
                            (!!name_label && name_label.length > 0) ? `
@currentFeatures: viewportCount()
@${county_label}: $${county_label}
@${fips_label}:  $${fips_label}
@${name_label}: $${name_label}` + field_names.map((field, i, a) => {
                                console.log("Map VIZ to field: ", field);
                                return (
                                    field.match(/carto/) === null &&
                                    field.match(/geom/) === null &&
                                    field.match(name_label) === null &&
                                    field.match(fips_label) === null &&
                                    field.match(county_label) === null &&
                                    field_types[i] !== 'logical'
                                ) ? `
@${field_labels[i]}: $${field_names[i]}` : '';
                            }).join('')  + (
                                (!!carto_table_styles[table])?
                                    carto_table_styles[table] : `
color: rgba(${convertColor(selected_color || '#C80E38')}, ${(!!geo_style && 'opacity' in geo_style) ? geo_style['opacity'] : 0.25})
strokeColor: ${(selected_color || '#C80E38')}`
                            ) + `
@v_features: viewportFeatures($${name_label})` : `
@currentFeatures: viewportCount()` + (
                                (!!left_join && left_join.length > 0) ?
                                    field_names.map((field, i, a) => {
                                        return (
                                            field.match(/carto/) === null &&
                                            field.match(/geom/) === null &&
                                            field_types[i] !== 'logical'
                                        ) ? `
@${field_labels[i]}: $${field_names[i]}` : '';
                                    }).join('') + `
@notes: $notes`
                                    :
                                    field_names.map((field, i, a) => {
                                        return (
                                            field.match(/carto/) === null &&
                                            field.match(/geom/) === null &&
                                            field_types[i] !== 'logical'
                                        ) ? `
@${field_labels[i]}: $${field_names[i]}` : '';
                                    }).join('')
                            )  + (
                                (!!carto_table_styles[table])?
                                    carto_table_styles[table] : `
color: rgba(${convertColor(selected_color || '#C80E38')}, ${(!!geo_style && 'opacity' in geo_style) ? geo_style['opacity'] : 0.25})
strokeColor: ${(selected_color || '#C80E38')}`
                            )
                        );

                        console.log('VIZ: ', viz1);

                        console.log("Adding layer ", table);

                        const enterFeature = featureEvent => {
                            featureEvent.features.forEach((feature) => {
                                if (!no_metrics && !!style_ramp) {
                                    feature.color.blendTo(`opacity(${style_ramp}, 0.75)`, 75);
                                }
                                feature.width.blendTo(20, 100);
                            });
                        };

                        const exitFeature = featureEvent => {
                            featureEvent.features.forEach((feature) => {
                                feature.color.reset();
                                feature.width.reset();
                            });
                        };

                        const clickFeature = featureEvent => {
                            if ("features" in featureEvent && featureEvent.features.length > 0) {

                                let new_location = window.location.toString()
                                    .match(/(https?\:\/\/[\w|\-|\_|\.|\:|\/]+(?:[\?|\&]geoids=[0-9|,]*)?)([\?|\&]?.+)?/)[1];

                                new_location += ((new_location.match(/\?/) === null) ? "?" : "&") + 'selectedLayer=' + table;

                                if (!no_metrics) {
                                    console.log("Metrics for " + table, metrics);
                                    console.log("metrics.map === " + typeof metrics.map);
                                }

                                notes = (!!left_join) ? "NO NOTES" : "";

                                featureEvent.features.forEach((feature) => {
                                    const feature_props = [];
                                    selected_table_id = table;
                                    selected_feature[selected_table_id] = {};
                                    const fields = [];

                                    notes = (!!left_join) ? "NO NOTES" : "";

                                    for (const f in feature.variables) {
                                        if (feature.variables.hasOwnProperty(f) && f !== "currentFeatures") {
                                            fields.push(f);
                                        } else if (f === "currentFeatures") {
                                            console.log("currentFeatures: ", feature.variables["currentFeatures"]);
                                        }
                                    }

                                    const feature_message = 'You have clicked on ' + (
                                            (name_label in feature.variables) ?
                                                (() => {
                                                    feature_props.push(name_label);
                                                    selected_feature[selected_table_id][name_label] = feature.variables[name_label].value;
                                                    new_location += ((window.location.toString().match(/\?/) === null) ? "?" : "&") +
                                                        `${name_label}=${feature.variables[name_label].value}`;
                                                    return `${feature.variables[name_label].value}:\n`;
                                                })() :
                                                (!!name_label && name_label.length > 0 && feature.variables.hasOwnProperty(name_label)) ? (() => {
                                                    feature_props.push(name_label);
                                                    selected_feature[selected_table_id][name_label] = feature.variables[name_label].value;
                                                    return `${name_label}: ${selected_feature[selected_table_id][name_label]}\n`;
                                                })() :
                                                    ``
                                        ) + (
                                            (!no_metrics && metrics.length > 0 && typeof metrics.map === 'function') ? metrics.map(metric => {
                                                    // {
                                                    //     name: "<metric>",
                                                    //     type: "<type>",
                                                    //     value_range: "<value(s)>"
                                                    // }
                                                    if (feature.variables.hasOwnProperty(metric.name)) {
                                                        console.log(metric.name + " found in VIZ");
                                                        feature_props.push(metric.name);
                                                        selected_feature[selected_table_id][metric.name] = feature.variables[metric.name].value;
                                                        new_location += ((window.location.toString().match(/\?/) === null) ? "?" : "&") +
                                                            `${metric.name}=${selected_feature[selected_table_id][metric.name]}`;
                                                        return `${metric.name} (${metric.type}): ${selected_feature[selected_table_id][metric.name]}\n`;
                                                    } else {
                                                        console.log(metric.name + " NOT found in VIZ");
                                                        return ``;
                                                    }
                                                }).join("") :
                                                ``
                                        ) + (
                                            (!!county_label && county_label.length > 0 && feature.variables.hasOwnProperty(county_label)) ? (() => {
                                                    feature_props.push(county_label);
                                                    selected_feature[selected_table_id][county_label] = feature.variables[county_label].value;
                                                    new_location += ((window.location.toString().match(/\?/) === null) ? "?" : "&") +
                                                        `${county_label}=${selected_feature[selected_table_id][county_label]}`;
                                                    return `${county_label}: ${selected_feature[selected_table_id][county_label]}\n`;
                                                })() :
                                                ``
                                        ) + (
                                            (!!fips_label && fips_label.length > 0 && feature.variables.hasOwnProperty(fips_label)) ? (() => {
                                                    feature_props.push(fips_label);
                                                    selected_feature[selected_table_id][fips_label] = feature.variables[fips_label].value;
                                                    new_location += ((window.location.toString().match(/\?/) === null) ? "?" : "&") +
                                                        `${fips_label}=${selected_feature[selected_table_id][fips_label]}`;
                                                    return `${fips_label}: ${selected_feature[selected_table_id][fips_label]}\n`;
                                                })() :
                                                ``
                                        ) +
                                        ((!!left_join) ? fields : field_names).map((field, i, a) => {
                                            console.log(field, feature.variables.hasOwnProperty(field));
                                            if (field === "notes") {
                                                notes = feature.variables[field].value || "NO NOTES";
                                            }

                                            if (feature.variables.hasOwnProperty(field) &&
                                                field.match(/carto/) === null &&
                                                field.match(/geom/) === null &&
                                                field.match(/style/) === null &&
                                                (!!no_metrics || metrics.filter(metric => field === metric.name).length < 1) &&
                                                (!name_label || field.match(name_label) === null) &&
                                                (!fips_label || field.match(fips_label) === null) &&
                                                (!county_label || field.match(county_label) === null) && (
                                                    typeof feature.variables[field].value === 'string' ||
                                                    typeof feature.variables[field].value === 'number'
                                                )
                                            ) {
                                                console.log(feature.variables[field].value);

                                                if (!!field_types[i] && !left_join) {
                                                    feature_props.push(field_labels[i]);
                                                    selected_feature[selected_table_id][field_labels[i]] = feature.variables[field_labels[i]].value;
                                                    new_location += ((window.location.toString().match(/\?/) === null) ? "?" : "&") +
                                                        `${field_labels[i]}=${selected_feature[selected_table_id][field_labels[i]]}`;
                                                    return `${field_labels[i]} (${field_types[i]}): ${selected_feature[selected_table_id][field_labels[i]]}\n`;
                                                } else {
                                                    feature_props.push(field);
                                                    selected_feature[selected_table_id][field] = feature.variables[field].value;
                                                    new_location += ((window.location.toString().match(/\?/) === null) ? "?" : "&") +
                                                        `${field}=${selected_feature[selected_table_id][field]}`;
                                                    return `${field} (${field_types[i]}): ${selected_feature[selected_table_id][field]}\n`;
                                                }
                                            } else {
                                                return '';
                                            }
                                        }).join('');

                                    console.log(feature_message);

                                    selected_feature_props = feature_props;
                                });

                                if (typeof map.contextFunction === 'function' && !!notes) {
                                    console.log(notes);

                                    console.log("TIMEOUT...", new_location);
                                    setTimeout(function () {
                                        (map.contextFunction.bind(map))(featureEvent);
                                        window.history.replaceState({}, document.title, new_location.toString());
                                    }, 253);
                                } else {
                                    console.log(new_location);
                                    window.history.replaceState({}, document.title, new_location.toString());
                                }
                            }
                        };

                        const layerInteractivity = function (layer) {
                            const interactivity = new carto.Interactivity(layer);

                            interactivity.on('featureEnter', enterFeature);
                            interactivity.on('featureLeave', exitFeature);
                            interactivity.on('featureClick', clickFeature);
                        }

                        if (!no_metrics) {

                            // (TABLE_ID, SQL, AUTH, CONFIG, VIZ, INTR, metric, color, value_range, time_period, style_ramp)
                            map.addCartoLayer(
                                table,
                                sql_query,
                                auth,
                                config,
                                viz1,
                                layerInteractivity,
                                metrics[0].name,
                                selected_color,
                                style_ramp,
                                (!!geo_style && 'opacity' in geo_style) ? geo_style['opacity'] : 0.25,
                                // value_range[(value_range.length - 1)] || value_range
                            );
                        } else {
                            // (TABLE_ID, SQL, AUTH, CONFIG, VIZ, INTR, metric, color, value_range, time_period, style_ramp)
                            map.addCartoLayer(
                                table,
                                sql_query,
                                auth,
                                config,
                                viz1,
                                layerInteractivity,
                                // metrics[0].name,
                                // selected_color,
                                // style_ramp,
                                // value_range[(value_range.length - 1)] || value_range
                            );
                        }

                    } else {

                        const sql_query = `select ` + (
                            (field_names.length > 0) ? field_names.join(',') : `*`
                        ) + ` from "${auth['username']}".${table}`
                        console.log('SQL: ', sql_query);

                        const viz1 = ((!!fips_label && fips_label.length > 0) && (!!name_label && name_label.length > 0)) ? `
@county: $${fips_label}
@name: $${name_label}` + (
    (!!carto_table_styles[table])?
        carto_table_styles[table] : `
color: rgba(${convertColor(selected_color || '#C80E38')}, ${(!!geo_style && 'opacity' in geo_style) ? geo_style['opacity'] : 0.25})
strokeColor: ${(selected_color || '#C80E38')}
strokeWidth: 2`
                        ) : ((!!name_label && name_label.length > 0)) ? `
@name: $${name_label}` + (
    (!!carto_table_styles[table])?
        carto_table_styles[table] : `
color: rgba(${convertColor(selected_color || '#C80E38')}, ${(!!geo_style && 'opacity' in geo_style) ? geo_style['opacity'] : 0.25})
strokeColor: ${(selected_color || '#C80E38')}
strokeWidth: 2`
                        ) : (
                            (!!carto_table_styles[table])?
                                carto_table_styles[table] : `
color: rgba(${convertColor(selected_color || '#C80E38')}, ${(!!geo_style && 'opacity' in geo_style) ? geo_style['opacity'] : 0.25})
strokeColor: ${(selected_color || '#C80E38')}
strokeWidth: 2`);

                        const enterFeature = featureEvent => {
                            featureEvent.features.forEach((feature) => {
                                // feature.color.blendTo(`opacity(${style_ramp}, 1.0)`, 100);
                                feature.width.blendTo(20, 100);
                            });
                        };

                        const exitFeature = featureEvent => {
                            featureEvent.features.forEach((feature) => {
                                feature.color.reset();
                                feature.width.reset();
                            });
                        };

                        const clickFeature = featureEvent => {
                            featureEvent.features.forEach((feature) => {
                                console.log(`You have clicked on : `, feature);
                            });
                        }

                        console.log("Adding layer ", table);

                        const layerInteractivity = function (layer) {
                            const interactivity = new carto.Interactivity(layer);

                            interactivity.on('featureEnter', enterFeature);
                            interactivity.on('featureLeave', exitFeature);
                            interactivity.on('featureClick', clickFeature);

                            all_layer_toggles[currentLayerIndex] = toggle_layers[table].checked;

                            console.log("Layer (" + (currentLayerIndex) + ") is on: ", table);
                            console.log("all_layer_toggles["+ currentLayerIndex + "] = " + all_layer_toggles[currentLayerIndex]);
                        }

                        // (TABLE_ID, SQL, AUTH, CONFIG, VIZ, INTR, metric, color, value_range, time_period, style_ramp)
                        map.addCartoLayer(
                            table,
                            sql_query,
                            auth,
                            config,
                            viz1,
                            layerInteractivity,
                            // metric,
                            // selected_color,
                            // style_ramp,
                            // value_range[(value_range.length - 1)] || value_range
                        );
                    }
                };

                toggle_layers[table].turn_off = function () {
                    map.removeLayerWithId(table);
                    if (!toggle_layers[table].buffer &&
                        legend_layers.length < 1 ||
                        legend_layers.filter(table_id => !!toggle_layers[table_id].checked && !toggle_layers[table_id].buffer).length < 1) {
                        st_buffer = save_buffer;
                        buffer = true;
                    }
                };

                if (!!carto_tables['tables_on']) {
                    if (table in toggle_layers) {
                        // // Init with layers on:
                        // setTimeout(async function() {
                        //     let retry = 3;
                        //     while (--retry > 0 && currentLayerIndex > 0 && !all_layer_toggles[currentLayerIndex - 1]) {
                        //         console.log("Check if previous layer (" + (currentLayerIndex - 1) + ") is on before turning on layer (" + (currentLayerIndex ) + "): ", table);
                        //         console.log("all_layer_toggles["+ (currentLayerIndex - 1) + "] = " + all_layer_toggles[(currentLayerIndex - 1)]);
                        //         await new Promise(resolve => setTimeout(resolve, delay));
                        //     }
                        //     console.log("Turn on layer (" + currentLayerIndex + "): ", table);
                        //     toggleLayer({ target: { checked: true } }, table);
                        // }, delay * currentLayerIndex);

                        // For now, only turn on very first layer
                        if (currentLayerIndex === 0) {
                            console.log("Turn on layer (" + currentLayerIndex + "): ", table);
                            toggleLayer({target: {checked: true}}, table);
                        }
                    }
                } else if (table in toggle_layers && !!toggle_layers[table].checked) {
                    toggleLayer({ target: { checked: true } }, table);
                }

                layerIndex += 1;
            }
        }

    }

    function convertColor(clr) {
        const r = parseInt('0x' + clr.substr(1, 2), 16),
            g = parseInt('0x' + clr.substr(3, 2), 16),
            b = parseInt('0x' + clr.substr(5, 2), 16);

        return `${r}, ${g}, ${b}`;
    }

    function hideLoader() {
        if (!!document.getElementById('loader')) {
            document.getElementById('loader').style.opacity = '0';
        }
    }

    onMount(() => {
        let frame;

        // window.alert("MOUNTED");

        console.log(basemaps);
        console.log(basemaps[(basemaps.length - 2)].id);

        if (!!window && !!window['Shiny']) {
            console.log("Wait for Shiny UI");

            // register
            Shiny.outputBindings.register(shinyMapToolBinding, "shinyMapTool");

        } else {
            fetch('data/test.json')
                .then(res => res.json())
                .then(data => {
                    return shinyMapToolBinding.renderValue(document.getElementById('mapApplication'), data);
                });
        }

        // window['test1'] = t => shinyMapToolBinding.renderValue(document.getElementById('mapApplication'), test1);
        window['test1'] = t => fetch('data/test1.json')
            .then(res => res.json())
            .then(data => {
                return shinyMapToolBinding.renderValue(document.getElementById('mapApplication'), data);
            });
        // window['test2'] = t => shinyMapToolBinding.renderValue(document.getElementById('mapApplication'), test2);
        window['test2'] = t => fetch('data/test2.json')
            .then(res => res.json())
            .then(data => {
                return shinyMapToolBinding.renderValue(document.getElementById('mapApplication'), data);
            });
        // window['test3'] = t => shinyMapToolBinding.renderValue(document.getElementById('mapApplication'), test3);
        window['test3'] = t => fetch('data/test3.json')
            .then(res => res.json())
            .then(data => {
                return shinyMapToolBinding.renderValue(document.getElementById('mapApplication'), data);
            });
        // window['test4'] = t => shinyMapToolBinding.renderValue(document.getElementById('mapApplication'), test4);
        window['test4'] = t => fetch('data/test4.json')
            .then(res => res.json())
            .then(data => {
                return shinyMapToolBinding.renderValue(document.getElementById('mapApplication'), data);
            });
        window['test5'] = t => fetch('data/test5.json')
            .then(res => res.json())
            .then(data => {
                return shinyMapToolBinding.renderValue(document.getElementById('mapApplication'), data);
            });
        window['test6'] = t => fetch('data/test6.json')
            .then(res => res.json())
            .then(data => {
                return shinyMapToolBinding.renderValue(document.getElementById('mapApplication'), data);
            });

        (function loop() {
            frame = requestAnimationFrame(loop);
            /** Animate stuff here **/
        }());

        return () => {
            cancelAnimationFrame(frame);
        };
    });

</script>

<style>
    /*@import url('styles/styles.css');*/

    #basemap-menu {
        position: absolute;
        bottom: 0px;
        width: 100%;
        margin: 0;
        background-color: rgba(0, 0, 0, 0.25);
        color: aliceblue;
        max-height: 56px;
        padding: 1em 2rem 3em;
        text-align: center;
        z-index: 100;
    }

    .controls {
        overflow: hidden;
        pointer-events: none;
        width: 96%;
        margin: 0 auto auto auto;
        max-height: 100vh;
    }

    @media (min-width: 640px) {
        .controls.toolbox {
            min-width: 440px;
            width: 33%;
            max-height: 75vh;
            overflow: hidden;
        }
        .controls.right.toolbox {
            right: 1%;
        }
    }

    @media (max-width: 640px) {
        aside.controls {
            margin: auto;
            left: auto;
            right: 0;
            top: 101%;
            width: 100%;
        }
    }

    @media (max-width: 480px) {
        aside.controls {
            min-width: 79vh;
        }
    }

    @media (max-width: 440px) {
        aside.controls {
            min-width: 75vh;
        }
    }

    @media (max-width: 400px) {
        aside.controls {
            min-width: 71vh;
        }
    }

    @media (max-width: 360px) {
        aside.controls {
            min-width: 63vh;
        }
    }

    .controls .box {
        /*height: 100%;*/
        max-height: 74vh;
        overflow-y: auto;
        pointer-events: visible;
        background: rgba(255, 255, 255, 0.75);
    }

    .controls .box header {
        max-height: 133px;
        overflow-x: auto;
    }

    .controls .box header h1 {
        max-width: max-content;
        min-width: max-content;
        max-height: 128px;
        overflow-x: auto;
    }

    .controls .box header *,
    .controls .box section * {
        text-align: left;
        text-shadow: none;
    }

    .controls .box section h3,
    .controls .box section h4,
    .controls .box section h5 {
        margin: 6px 0px;
    }

    .controls .box label {
        font-size: 1em;
    }

    .controls .box label .minimum_rate {
        font-size: 0.75em;
    }

    .controls .box label input[type="color"] {
        float: left;
        height: 18px;
        width: 24px;
        margin: 10px 2px 10px;
        padding: 2px;
    }

    .controls.toolbox .box .layer-filter-toggle,
    .controls.toolbox .box * .layer-legend-toggle {
        --width: 40px;
        --height: calc(var(--width) / 2);
        --border-radius: calc(var(--height) / 2);

        display: inline-block;
        cursor: pointer;
    }

    .controls.toolbox .box .layer-filter-toggle label[for="filter-range"] {
        font-weight: lighter;
        padding: 0.5em 4em;
    }

    .controls.toolbox .box .layer-legend * li {
        list-style-type: none;
    }

    .controls.toolbox .box .layer-legend * li .point-mark {
        margin-left: 20px;
    }

    /*.controls.toolbox .box .layer-legend #___ li .point-mark:before {*/
    /*     content: '';*/
    /*     display: inline-block;*/
    /*     height: 1em;*/
    /*     width: 1em;*/
    /*     background-image: url('https://coriassets.s3.amazonaws.com/carto_pint.svg');*/
    /*     background-size: contain;*/
    /*     background-repeat: no-repeat;*/
    /*     margin-right: 0.5em;*/
    /* }*/

    .controls.toolbox .box * .toggle__input {
        display: none;
    }

    .controls.toolbox .box * .toggle__fill {
        display: inline-block;
        position: relative;
        margin: 2px 2px -4px 0;
        width: var(--width);
        height: var(--height);
        border-radius: var(--border-radius);
        background: #dddddd;
        transition: background 0.2s;
    }

    .controls.toolbox .box * .toggle__fill::after {
        content: "";
        position: absolute;
        top: 0;
        left: 0;
        height: var(--height);
        width: var(--height);
        background: #ffffff;
        box-shadow: 0 0 10px rgba(0, 0, 0, 0.25);
        border-radius: var(--border-radius);
        transition: transform 0.2s;
    }

    .controls.toolbox .box * .toggle__input:checked ~ .toggle__fill {
        background: #2b6ec0;
    }

    .controls.toolbox .box * .toggle__input:checked ~ .toggle__fill::after {
        transform: translateX(var(--height));
    }

    @keyframes fadeInOpacity {
        0% {
            opacity: 0;
        }
        100% {
            opacity: 1;
        }
    }

    @keyframes fadeOutOpacity {
        0% {
            opacity: 1;
        }
        100% {
            opacity: 0;
        }
    }

    *>.tooltip {
        background-color: transparent;
        border: none;
        /*pointer-events: none;*/
        opacity: 0;
        overflow: hidden;
        transition: opacity 0.5s ease-in 0.5s;
        visibility: hidden;

        /* Position the tooltip */
        position: absolute;
        z-index: 1;
    }

    *>.tooltip::after {
        visibility: visible;
    }

    *:hover>.tooltip {
        /*animation-name: fadeInOpacity;*/
        /*animation-delay: 0.5s;*/
        /*animation-duration: 0.5s;*/
        /*animation-iteration-count: 1;*/
        /*animation-timing-function: ease-in;*/
        /*position: relative;*/
        opacity: 1;
        overflow: visible;
        visibility: visible;
    }

    *:hover>.tooltip>.tooltiptext,
    *>.tooltip:hover>.tooltiptext,
    *>.tooltip>.tooltiptext:hover {
        visibility: visible;
    }

    *:hover>.tooltip>.tooltiptext,
    *>.tooltip:hover>.tooltiptext,
    *>.tooltip>.tooltiptext:hover {
        display: block;
        position: relative;
        width: 240px;
        background-color: rgba(0, 0, 0, 0.5);
        color: #fff;
        text-align: center;
        border-radius: 6px;
        padding: 5px 0;
    }

    *>.tooltip.center {
        position: fixed;
        left: 50%;
        top: 50%;
        z-index: 1;
    }

    *>.tooltip.right {
        position: fixed;
        right: 1%;
        top: 50%;
        z-index: 1;
    }

    *>.tooltip.center>.tooltiptext {
        margin: -50%  -50%;
    }

    .data-properties {
        list-style: outside none none;
        height: 120px;
        overflow: auto;
        padding: 1em;
        display: block;
        padding: 9.5px;
        margin: 0 0 10px;
        font-size: 13px;
        line-height: 1.42857143;
        color: #333;
        word-break: break-all;
        word-wrap: break-word;
        background-color: #f5f5f5;
        border: 1px solid #ccc;
        border-radius: 4px;
    }

    .mapboxgl-popup-content {
        display: none;
        border: 2px solid grey; border-radius: 2px;
    }

    .mapboxgl-popup-content .add-prompt {
        display: none;
    }

    .mapboxgl-popup-content .remove-prompt {
        display: none;
    }

    #tool-title {
        color: #fbf8e9;
        font-family: "Montserrat", sans-serif;
        font-size: 1.5em;
        font-weight: 400;
        min-width: 440px;
        padding: 8px 36px;
        vertical-align: baseline;
        margin: 2px 24px;
    }

    #tool-title a {
        font-family: "TTHoves-Bold", "Montserrat", Arial, sans-serif;
        font-weight: 700;
        color: #fbf8e9;
        text-decoration: #fbf8e9 solid;
    }

    #tool-title a.help-doc {
        padding: 0;
        vertical-align: super;
    }

    #tool-title a i {
        display: none;
    }

    /* DEBUG */
    /*#tool-title > a > .cori-risi.risi-logo {*/
    /*    display: inline-block;*/
    /*}*/
    /*#tool-title > a > .cori-risi.risi-logo:before {*/
    /*    color: #fbf8e9;*/
    /*    background: #16343E;*/
    /*    border: 16px solid #16343E;*/
    /*}*/

</style>

<div id="basemap-menu" class="box">
    <!--<span style="float: left">Basemap: { basemap.label }</span>-->
    {#each basemaps.sort((a,b) => { console.log(a, b); return (a > b) ? -1 : 1 }) as bm}
        <label for="{(b => { console.log(b); return b})(bm)}" style="margin: 8px;">
            <!--{#if basemap.id == bm.id}-->
            <input id="{bm.id}" style="margin:2px" type="radio" name="{bm.name}" value="{bm.id}" bind:group="{basemap}" checked="{(basemap.id == bm.id) ? 'checked' : ''}">
            <!--{:else}-->
            <!--    <input id="{bm.id}" style="margin:2px" type="radio" name="{bm.name}" value="{bm.id}" bind:group="{basemap}">-->
            <!--{/if}-->
            {bm.label}</label>
    {/each}
</div>

{#if (!!legend_layers.length > 0 && !!tool_title)}
    <aside class="controls right toolbox">
        <div class="box">

            {#if (!!fips && !!selection['id'] && !!show_geo_info)}
                <header>
                    <h1>{ selection['id'] }</h1>
                </header>
                <hr/>

                <ul class="data-properties">
                    <!--<li><span style="font-weight:bold;">{selection['id']}</span></li>-->
                    {#each selection['props'] as prop}{#if (!!selection['properties'][prop])}
                        <li><strong>{prop}</strong>: {selection['properties'][prop]}</li>
                    {/if}{/each}
                </ul>
                <hr/>

                <div class="layer-filter-toggle">
                    <label for="toggle-filter">
                        <input id="toggle-filter" class="toggle__input" checked="{((!!filter_by_selection) ? 'checked' : '')}" type="checkbox" on:change={e => toggleFilter(e, true)} />
                        <div class="toggle__fill"></div>
                        <span style="font-weight:normal;">Filter Layers By Selected Geography</span>
                    </label>
                    {#if (!!filter_by_selection && !!buffer)}
                        <label for="filter-range">Intersects area within {st_buffer} miles of geography
                            <input id="filter-range" type="range" bind:value={st_buffer} min={1} max={50} step={1} on:change={e => { save_buffer = st_buffer; toggleFilter(e) }}>
                        </label>
                    {/if}
                </div>
                <hr />
            {/if}

            {#if (!!selected_table_id)}
                <ul class="data-properties">
                    <li><span style="font-weight:bold;">{carto_table_labels[selected_table_id]}</span></li>
                    {#each selected_feature_props as prop}{#if (!!selected_feature[selected_table_id][prop])}
                        <li><strong>{prop}</strong>: {selected_feature[selected_table_id][prop]}</li>
                    {/if}{/each}
                </ul>
                <hr/>
            {/if}

            {#if (!!legend_layers.length > 0)}
                <div id="legend" class="layer-legend">
                    {#each legend_layers as table_id}
                        <div id="legend-{table_id}">
                            <label class="layer-legend-toggle" for="toggle-{table_id}">
                                <input id="toggle-{table_id}" class="toggle__input" value="{table_id}" checked="{((!!toggle_layers[table_id].checked) ? 'checked' : '')}" type="checkbox" on:change={e => toggleLayer(e, table_id)} />
                                <span style="display:inline-block" class="toggle__fill"></span>
                                <span style="font-weight:bold;">
                                    {carto_table_labels[table_id]}
                                </span>
                                {#if (!!carto_table_info[table_id])}
                                    <span class="tooltip right" style="{`content: '${carto_table_info[table_id]}'`}">
                                        <span class="tooltiptext">{carto_table_info[table_id]}</span>
                                    </span>
                                {/if}
                            </label>
                            {#if (!!toggle_layers[table_id].checked)}
                            <div id="legend-{table_id}-colors">
                                <div class="CDB-LoaderIcon CDB-LoaderIcon--big svelte-cs19r4" style="margin-left: 40px;">
                                    <svg class="CDB-LoaderIcon-spinner svelte-cs19r4" style="width: 25px;height: 25px;" viewBox="0 0 50 50">
                                        <circle class="CDB-LoaderIcon-path svelte-cs19r4" cx="25" cy="25" fill="none" r="20"></circle>
                                    </svg>
                                </div>
                            </div>
                            {/if}
                        </div>
                    {/each}
                </div>
            {/if}

            <footer class="js-footer"></footer>
        </div>
    </aside>
{/if}

<div id="loader">
    <div class="CDB-LoaderIcon CDB-LoaderIcon--big">
        <svg class="CDB-LoaderIcon-spinner" viewBox="0 0 50 50">
            <circle class="CDB-LoaderIcon-path" cx="25" cy="25" r="20" fill="none"></circle>
        </svg>
    </div>
</div>

<div id="selection-popup" class="mapboxgl-popup-content">
    {notes}
    <br />
    <form  class="add-prompt">
        Add $geoid to the selection filter?
        <br />
        <button value="yes">YES</button>
        <button value="no">NO</button>
    </form>
    <form  class="remove-prompt">
        Remove $geoid from the selection filter?
        <br />
        <button value="yes">YES</button>
        <button value="no">NO</button>
    </form>
</div>

<!--<div id="tooltip"></div>-->

<div id='tool-title'>
    <a href="#" data-toggle="tab" data-value="{tool_title}">
        <i class=" cori-risi cori-logo" role="presentation" aria-label=" icon"></i>
        <i class=" cori-risi risi-logo" role="presentation" aria-label=" icon"></i>
        {tool_title}
    </a>
    {#if (!!help_doc)}
        <a class="btn-sm help-doc" href="{help_doc}" target="_blank">
            <i class="glyphicon glyphicon-question-sign"
               style="display: inline-block; color: white; width: 12px;height: 12px;" ></i>
        </a>
    {/if}
</div>
