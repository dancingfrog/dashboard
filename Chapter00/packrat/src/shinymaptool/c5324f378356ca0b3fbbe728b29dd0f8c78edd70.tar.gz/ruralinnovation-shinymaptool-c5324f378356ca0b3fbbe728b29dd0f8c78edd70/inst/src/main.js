import App from './App.svelte';

function mountReplace(Component, options) {
	const frag = document.createDocumentFragment();
	const component = new Component({ ...options, target: frag });

	options.target.parentNode.replaceChild(frag, options.target);

	return component;
}

const appElement =  (new Promise(function(resolve, reject){
	const wait_for_body = setInterval(function(response) {
		const elm = document.getElementById('svelte')
		console.log(elm)
		if (// Check if appElement exists in DOM
			elm !== null
			&& (elm.constructor.name === 'HTMLElement' ||
				elm.constructor.name === 'HTMLBodyElement' ||
				elm.constructor.name === 'HTMLDivElement')
		) {
			clearInterval(wait_for_body);
				resolve(elm); //resolve(document.getElementById(appId));

		} else {
			// console.log("wait");
		}

	}, 3);
})
);

const app = {}

appElement.then(async function (elm) {
	console.log("UPDATE app");
	const initApp = // usage
		mountReplace(App, {
			target: elm,
			props: {
				// authenticated: false, // set to true to ignore auth state
				// name: 'world',
				// toolTitle: "Shiny Map Tool",
				VERSION: "VERSION_NUMBER"
			}
		});

	for (const[p] in initApp) {
		app[p] = initApp[p];
	}
});

export default app;