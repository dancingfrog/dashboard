import carto from "@carto/carto-vl";
import mapboxgl from "mapbox-gl";
import turf from "@turf/turf";

export let selection_popup = {};
let context_selection = "NOCONTEXT";
let default_zoom = 9;

const basemaps = [
    // <!-- See a list of Mapbox-hosted public styles at -->
    // <!-- https://docs.mapbox.com/api/maps/styles/#mapbox-styles -->,
    { id:"satellite-v9" },
    { id:"streets-v11" }
];
let currentLayer = {};
let geom_data = {};
let geom_initialized = false;
let map;
let mapBounds = [
    [ -80.83415919532996, 39.98043619521454 ],
    [ -73.45134669532756, 35.74110771792324 ]
];
let intrById = {};
let layerA = {};
let layerB = {};
let removeDelayA = {};
let removeDelayB = {};

export default class CartoMapbox {
    constructor (
        map_container = document.getElementById("mapApplication") || null,
        mapbox_key = "pk.eyJ1Ijoiam9leWtsZWUiLCJhIjoiMlRDV2lCSSJ9.ZmGAJU54Pa-z8KvwoVXVBw",
        mapId = "my-map",
        mb = mapBounds,
        initView = {},
        basemap = `mapbox://styles/mapbox/${basemaps[3].id}`,
        layersById = {}
    ) {

        // Carto VL credentials
        carto.setDefaultAuth({
            apiKey: 'default_public',
            username: 'dancingfrog'
        });

        // Mapbox GL credentials
        mapboxgl.accessToken = mapbox_key;

        console.log('Initializing carto-mapbox with these options: ', {
            container: mapId,
            style: `mapbox://styles/mapbox/${basemap}`,
            interactive: true,
            center: [ initView.longitude, initView.latitude ],
            zoom: initView.zoom,
            bearing: initView.bearing,
            pitch: initView.pitch,
        });

        map = new mapboxgl.Map({
            container: mapId,
            // style: carto.basemaps.darkmatter,
            // style: carto.basemaps.positron,
            // style: carto.basemaps.voyager,
            style: `mapbox://styles/mapbox/${basemap}`,
            // Note: deck.gl will be in charge of interaction and event handling
            interactive: true,
            center: [ initView.longitude, initView.latitude ],
            zoom: initView.zoom,
            bearing: initView.bearing,
            pitch: initView.pitch,
        });

        map.addControl(new mapboxgl.NavigationControl({
            showCompass: false
        }), 'top-left');

        map.addControl(new mapboxgl.FullscreenControl(), 'top-left');

        map.constructor.prototype.container = map_container;

        // map.constructor.prototype.addLayer = this.addLayer; <- DO NOT DO THIS
        map.constructor.prototype.addCartoLayer = this.addCartoLayer;
        map.constructor.prototype.addGeoJSONLayer = this.addGeoJSONLayer;
        map.constructor.prototype.addLayerToMap = this.addLayerToMap;
        map.constructor.prototype.removeLayerWithId  = this.removeLayerWithId;
        map.constructor.prototype.getGeomDataFeatures  = this.getGeomDataFeatures;
        map.constructor.prototype.setGeomDataFeatures  = this.setGeomDataFeatures;
        map.constructor.prototype.changeBasemap = this.changeBasemap;
        map.constructor.prototype.contextFunction = this.contextFunction;
        map.constructor.prototype.layersById = layersById;

        // TODO: Instead of removing individual boundaries... "Clear Boundary Selection?" YES NOs
        // map.on('contextmenu', this.contextFunction);

    }

    contextFunction (e) {
        console.log(e);


        if ('coordinates' in e || 'lngLat' in e) {

            //lngLat { lng, lat }
            //point { x, y }

            const coordinates = ('coordinates' in e) ?
                [ e.coordinates.lng, e.coordinates.lat ] :
                [ e.lngLat.lng, e.lngLat.lat ];

            // // Ensure that if the map is zoomed out such that multiple
            // // copies of the feature are visible, the popup appears
            // // over the copy being pointed to.
            // while (Math.abs(e.lngLat.lng - coordinates[0]) > 180) {
            //     coordinates[0] += e.lngLat.lng > coordinates[0] ? 360 : -360;
            // }

            console.log("Context on coordinates: ", coordinates);

            const contained_in_geoids = [];

            for (const geoid in this.getGeomDataFeatures()) try {
                const boundary_feature = this.getGeomDataFeatures()[geoid];
                if (boundary_feature.hasOwnProperty('geometry') &&
                    boundary_feature.geometry.hasOwnProperty('type') &&
                    boundary_feature.geometry.type.match(/Polygon/) !== null
                ) {
                    const point = turf.point(coordinates);
                    const polygon = (boundary_feature.geometry.type.match(/Multi/) !== null) ?
                        turf.multiPolygon(boundary_feature.geometry.coordinates) :
                        turf.polygon(boundary_feature.geometry.coordinates);

                    if (turf.booleanPointInPolygon(point, polygon)) {
                        contained_in_geoids.push(geoid)
                        console.log(`Point is in  ${geoid}`);
                        break;
                    }
                }
            } catch (e) {
                console.error(e);
            }

            const selection_el = window['popup'] = document.getElementById('selection-popup');
            selection_el.style = "border: 2px solid grey; border-radius: 2px;";

            const add_geoid_prompt_el = selection_el.getElementsByClassName('add-prompt');
            const remove_geoid_prompt_el = selection_el.getElementsByClassName('remove-prompt');

            /* TODO: Given coordinates need service to assess if the county boundary
             * that the point-of-click falls within has already been selected by the user...
             * ... if not, show selection option in context menu and select if option clicked
             */

            try {
                add_geoid_prompt_el[0].style = "display: none";
                remove_geoid_prompt_el[0].style = "display: none";

                if (!!selection_popup && typeof selection_popup['remove'] === 'function') {
                    console.log(remove_geoid_prompt_el[0].innerHTML.replace(new RegExp(context_selection, "gi"), "$geoid"));
                    remove_geoid_prompt_el[0].innerHTML = remove_geoid_prompt_el[0].innerHTML.replace(new RegExp(context_selection, "gi"), "$geoid");
                    selection_popup.remove();
                }

            } finally {

                selection_popup = new mapboxgl.Popup()
                    .setHTML(selection_el.innerHTML)
                    .setLngLat(coordinates)
                    .addTo(map);

                // console.log(contained_in_geoids);
                //
                // if (contained_in_geoids.length > 0) contained_in_geoids.forEach(geoid => {
                //     console.log(remove_geoid_prompt_el[0].innerHTML.replace(new RegExp("\\$geoid", "gi"), context_selection));
                //
                //     context_selection = contained_in_geoids.join(",");
                //     remove_geoid_prompt_el[0].innerHTML = remove_geoid_prompt_el[0].innerHTML.replace(new RegExp("\\$geoid", "gi"), context_selection);
                //     remove_geoid_prompt_el[0].style = "display: block";
                //     add_geoid_prompt_el[0].style = "display: none";
                //
                //     selection_popup = new mapboxgl.Popup()
                //         .setLngLat(coordinates)
                //         .setHTML(selection_el.innerHTML)
                //         .addTo(map);
                //
                // }); else {
                //     console.log(remove_geoid_prompt_el[0].innerHTML.replace(new RegExp(context_selection, "gi"), "$geoid"))
                //
                //     add_geoid_prompt_el[0].style = "display: none";
                //     remove_geoid_prompt_el[0].style = "display: none";
                //     remove_geoid_prompt_el[0].innerHTML = remove_geoid_prompt_el[0].innerHTML.replace(new RegExp(context_selection, "gi"), "$geoid");
                //
                //     selection_popup = new mapboxgl.Popup()
                //         .setLngLat(coordinates)
                //         .setHTML(selection_el.innerHTML)
                //         .addTo(map);
                // }
            }
        }
    }

    addGeoJSONLayer (ID, GEOM, VIZ, INTR, JUMP_FUNC, FORCE_JUMP) {
        if ('type' in GEOM && GEOM.type === 'FeatureCollection') {
            const jumps = []
            const jumpToNewLocations = function (evt) {
                let delay = (!!geom_initialized)? 533 : 2533;//ms
                let iter = 0;
                // for (const j in jumps) {
                //     setTimeout(jumps[iter], delay * ++iter);
                // }
                setTimeout(jumps[(jumps.length - 1)], delay);
            };

            console.log('geom_data: ', geom_data);

            GEOM.features.forEach((feature, g) => {
                console.log(g, GEOM.features[g]);

                const geometry = GEOM.features[g].geometry;
                const properties = GEOM.features[g].properties;
                if (geometry.type === 'Point' || geometry.type === 'Polygon' || geometry.type === 'MultiPolygon') {
                    if (!('features' in geom_data)) {
                        geom_data['type'] = "FeatureCollection";
                        geom_data['features'] = [];
                        geom_data['past_features'] = [];
                    }

                    console.log(geom_data.features);
                    console.log(geom_data.past_features);
                    console.log(geom_data.features.concat(geom_data.past_features));

                    const shared_geom_features = geom_data.features //.concat([...new Set(geom_data.past_features)])
                        .filter(d => {
                            if (typeof d.properties['geoid'] != 'undefined'){
                                if (d.properties['geoid'] === properties['geoid'] || (
                                    typeof properties['geoid'].split(";").filter === 'function' &&
                                    typeof d.properties['geoid'].split(";").filter === 'function' &&
                                    properties['geoid'].split(";").filter(f => d.properties['geoid'].split(";").filter(df => f === df).length > 0).length > 0
                                )) {
                                    console.log(d.properties['geoid'], typeof d.properties['geoid'], typeof properties['geoid']);
                                    return true;
                                }
                            } else if (typeof d.properties['geoid_co'] != 'undefined'){
                                console.log(d.properties['geoid_co'], typeof d.properties['geoid_co']);
                                console.log(properties['geoid_co'], typeof properties['geoid_co']);
                                if (d.properties['geoid_co'] === properties['geoid_co'] || (
                                    typeof properties['geoid_co'].split(";").filter === 'function' &&
                                    typeof d.properties['geoid_co'].split(";").filter === 'function' &&
                                    properties['geoid_co'].split(";").filter(f => d.properties['geoid_co'].split(";").filter(df => f === df).length > 0).length > 0
                                )) {
                                    console.log(d.properties['geoid_co'], typeof d.properties['geoid_co'], typeof properties['geoid_co']);
                                    return true;
                                }
                            } else if (typeof d.properties['address'] != 'undefined' &&d.properties['address'] === properties['address']) {
                                console.log(d.properties['address'], typeof d.properties['address'], typeof properties['address']);
                                return true;
                            } else if (typeof d.properties['height'] != 'undefined' &&d.properties['height'] === properties['height']) {
                                console.log(d.properties['height'], typeof d.properties['height'], typeof properties['height']);
                                return true;

                            } else return false;
                        });

                    console.log(shared_geom_features);
                    console.log('Shared feature? ', shared_geom_features.length);

                    let wv_offset = 0;
                    let hv_offset = 0;

                    if(!!this.container) try {
                        // Offset zoom center for small screens (< 1200)
                        const container_bb = this.container.getBoundingClientRect();
                        if ((container_bb['width'] - 400) < 1200) {
                            wv_offset = (container_bb['width'] - 400) * 0.00028;
                            console.log("W OFFSET +", wv_offset);
                        }
                    } catch (e) {
                        console.error(e);
                    }

                    if (shared_geom_features.length < 1) {

                        console.log("push: ", properties);

                        geom_data.features.push({
                            "type": "Feature",
                            "geometry": geometry,
                            "properties": properties
                        });

                        console.log('GEOM feature length! ', GEOM.features.length);

                        // Only jump to location if not previously selected during this session or FORCE_JUMP is true
                        if (([...new Set(geom_data.past_features)])
                            .filter(d => {
                                    if (typeof d.properties['geoid'] != 'undefined'){
                                        if (d.properties['geoid'] === properties['geoid'] || (
                                            typeof properties['geoid'].split(";").filter === 'function' &&
                                            typeof d.properties['geoid'].split(";").filter === 'function' &&
                                            properties['geoid'].split(";").filter(f => d.properties['geoid'].split(";").filter(df => f === df).length > 0).length > 0
                                        )) {
                                            console.log(d.properties['geoid'], typeof d.properties['geoid'], typeof properties['geoid']);
                                            return true;
                                        }
                                    } else if (typeof d.properties['geoid_co'] != 'undefined'){
                                        console.log(d.properties['geoid_co'], typeof d.properties['geoid_co']);
                                        console.log(properties['geoid_co'], typeof properties['geoid_co']);
                                        if (d.properties['geoid_co'] === properties['geoid_co'] || (
                                            typeof properties['geoid_co'].split(";").filter === 'function' &&
                                            typeof d.properties['geoid_co'].split(";").filter === 'function' &&
                                            properties['geoid_co'].split(";").filter(f => d.properties['geoid_co'].split(";").filter(df => f === df).length > 0).length > 0
                                        )) {
                                            console.log(d.properties['geoid_co'], typeof d.properties['geoid_co'], typeof properties['geoid_co']);
                                            return true;
                                        }
                                    } else if (typeof d.properties['address'] != 'undefined' &&d.properties['address'] === properties['address']) {
                                        console.log(d.properties['address'], typeof d.properties['address'], typeof properties['address']);
                                        return true;
                                    } else if (typeof d.properties['height'] != 'undefined' &&d.properties['height'] === properties['height']) {
                                        console.log(d.properties['height'], typeof d.properties['height'], typeof properties['height']);
                                        return true;

                                    } else return false;
                                }).length < 1 ||
                            !!FORCE_JUMP
                        ) {
                            console.log("JUMP to new feature selection");

                            const jump_center = [
                                /*longitude:*/ wv_offset + ((geometry.type == 'Point') ?
                                        geometry.coordinates[0] :
                                        +(parseFloat(properties.lon)) // geometry.coordinates[0][0][0]
                                ),
                                /*latitude:*/ hv_offset + ((geometry.type === 'Point') ?
                                        geometry.coordinates[1] :
                                        +(parseFloat(properties.lat)) // geometry.coordinates[0][0][1]
                                )
                            ]

                            if (parseFloat(jump_center[0]) === parseFloat(jump_center[0])) {
                                // JUMP
                                jumps.push(function () {
                                    // alert(`FLY TO ${jump_center[0]}, ${jump_center[1]}`);

                                    const saveLayers = {};
                                    for (const l in map.layersById) try {
                                        if (map.layersById.hasOwnProperty(l) && l.match(/^geo/) === null) {
                                            saveLayers[l] = map.layersById[l];
                                            map.layersById[l].remove();
                                            delete map.layersById[l];
                                        }
                                    } catch (e) {
                                        console.error(e);
                                    }

                                    console.log("Pan map to ", jump_center)
                                    console.log("Zoom to ", default_zoom)

                                    if (!!JUMP_FUNC && typeof JUMP_FUNC === 'function') {
                                        JUMP_FUNC([], +jump_center[0], +jump_center[1], 9);

                                    } else {
                                        map.flyTo({
                                            center: jump_center,
                                            zoom: default_zoom,
                                            essential: true // this animation is considered essential with respect to prefers-reduced-motion
                                        });
                                    }


                                    for (const l in saveLayers) {

                                        setTimeout(function () {
                                            try {
                                                const layer = saveLayers[l]
                                                console.log("recover saved layer: ", l)
                                                if (typeof intrById[l] === 'function') {
                                                    layer.on('loaded', async (evt) => {
                                                        // console.log('LAYER LOADED: ', evt);
                                                        intrById[l](layer);
                                                    });
                                                }
                                                map.addLayerToMap(l, layer);
                                            } catch (e) {
                                                console.error(e);
                                            }
                                        }, (l.match(/^geo/) !== null) ? 533 : 1253);
                                    }
                                });
                            }
                        }

                    }
                }
            });

            if (!!geom_data && 'features' in geom_data) {
                console.log('GEOM DATA: ', geom_data);

                const source = new carto.source.GeoJSON(geom_data);
                const viz = (!!VIZ) ? new carto.Viz(VIZ) : new carto.Viz();
                const layer = new carto.Layer(ID, source, viz);

                try {

                    console.log("addLayer: ", layer);

                    layer.on('loaded', async (evt) => {
                        if (typeof INTR === 'function') {
                            // console.log('LAYER LOADED: ', layer);
                            intrById[ID] = INTR;
                            intrById[ID](layer);
                        }
                    });

                    /*layer.on('loaded',*/ jumpToNewLocations() //);

                    geom_initialized = true;

                    return this.addLayerToMap(ID, layer);

                } catch (e) {
                    console.error(e);
                    return e;

                }
            }

        }
    }

    addCartoLayer (TABLE_ID, SQL, AUTH, CONFIG, VIZ, INTR, metric, color, style_ramp, opacity, value) {

        console.log('SQL: ', SQL);

        const source = new carto.source.SQL(
            // `select * from "ruralinnovation-admin".dod_covid_county where death_cause ilike 'Suicide'`,
            SQL,
            AUTH, // {
            //     apiKey: 'kVxMWSUu7VvOzJNjUopfoQ',
            //     username: 'ruralinnovation-admin'
            // },
            CONFIG, //{
            //     serverURL: 'https://ruralinnovation-admin.carto.com'
            // }
        );

        const viz = new carto.Viz(VIZ);

        const layer = new carto.Layer(TABLE_ID, source, viz);


        // layer.on('loaded', hideLoader);

        console.log("addLayer: ", layer);


        layer.on('loaded', async (evt) => {
            // console.log('LAYER LOADED: ', evt);

            // Render Legend
            // Request data for legend from the layer viz
            const colorLegend = layer.viz.color.getLegendData();
            let colorLegendList = '';

            // Create list elements for legend
            colorLegend.data.forEach((legend) => {
                // alert(legend.key);
                if (legend.key != "CARTO_VL_OTHERS") {
                    const label = (!!legend.key) ?
                        (parseInt(legend.key) === parseInt(legend.key) && Math.round(legend.key) == legend.key) ?
                            Math.round(legend.key) :
                            (parseFloat(legend.key) === parseFloat(legend.key)) ?
                                legend.key.toFixed(2) :
                                legend.key : TABLE_ID;
                    const color = legend.value;
                    const rgba = `rgba(${color.r}, ${color.g}, ${color.b})`;
                    console.log(`Legend value ${label} = ${rgba}`);

                    // Style for legend items
                    colorLegendList += (color.r === 255 && color.g === 255 && color.b === 255) ? `
<li style="list-style-type:none;">
  <span class="point-mark"></span> 
  <span>${label}</span><br />
</li>\n` : `
<li style="list-style-type:none;">
  <span class="point-mark" style="background-color:rgba(${color.r}, ${color.g}, ${color.b});border: 1px solid black;"></span> 
  <span>${label}</span><br />
</li>\n`;
                }
            });

            console.log("Render legend with id: ", `legend-${TABLE_ID}-colors`, colorLegend.data);
            console.log("... based on style: ", style_ramp, opacity);

            // if (colorLegend.data.length > 0) {
                // Place list items in the content section of the title/legend box
                document.getElementById(`legend-${TABLE_ID}-colors`).innerHTML = colorLegendList;
            // }

            if (typeof INTR === 'function') {
                intrById[TABLE_ID] = INTR;
                intrById[TABLE_ID](layer);
            }

            if (!!style_ramp) {
                // Fade In
                layer.viz.color.blendTo(`opacity(${style_ramp}, ${opacity})`);
            }
        });

        return this.addLayerToMap (TABLE_ID, layer, metric, color, style_ramp, value);
    }
    
    

    addLayerToMap (ID, layer, metric, color, style_ramp, value) {

        function addNow () {
            console.log("Add Layer with ID: ", ID);
            layer.addTo(map);
            map.layersById[ID] = layer;
            console.log(`Layer ${ID} added`);
        }

        // Add layer to map
        if (!!layer) {
            console.log("layers", map.layersById);

            if (ID in map.layersById) try {

                if (!!metric && !!color && !!style_ramp) {
                    console.log(metric, color, style_ramp);

                    if (currentLayer[metric] === 'B') { // !!layerB[metric] && layerB[metric].hasOwnProperty("id") && layerB[metric].hasOwnProperty("id")) {
                        // Fade out B
                        console.log("Fade layer " + metric + "B");
                        if (!(!!layerB[metric])) {
                            layerB[metric] = map.layersById[ID];
                        }
                        layerB[metric].viz.color.blendTo(`opacity(${style_ramp}, 0.05)`)
                        removeDelayB[metric] = setTimeout(() => {
                            if (currentLayer[metric] !== 'B' && layerB[metric] != layer) {
                                console.log("Removing layer " + metric + "B");
                                layerB[metric].remove();
                            }
                        }, 233);
                        layer.on('loaded', function () {
                            currentLayer[metric] = metric + 'A';
                            layerA[metric] = layer;
                        });
                        setTimeout(addNow, 533);

                    } else {
                        // Fade out A
                        console.log("Fade layer " + metric + "A");
                        if (!(!!layerA[metric])) {
                            layerA[metric] = map.layersById[ID];
                        }
                        layerA[metric].viz.color.blendTo(`opacity(${style_ramp}, 0.05)`)
                        removeDelayA[metric] = setTimeout(() => {
                            if (currentLayer[metric] !== 'A' && layerA[metric] != layer) {
                                console.log("Removing layer " + metric + "A");
                                layerA[metric].remove();
                            }
                        }, 233);
                        layer.on('loaded', function () {
                            currentLayer[metric] = metric + 'B';
                            layerB[metric] = layer;
                        });
                        setTimeout(addNow, 533);

                    }

                } else {
                    console.log("removeLayer: ", ID);

                    try {
                        map.removeLayer(ID);
                    } finally {
                        setTimeout(addNow, 33);
                    }
                }

            } finally {

                delete map.layersById[ID];

            } else {
                setTimeout(addNow, 33);
            }

        }

        return layer;
    }

    removeLayerWithId (ID) {
        if (ID in map.layersById) {
            console.log("removeLayer: ", ID);
            map.removeLayer(ID);
            delete map.layersById[ID];

            if (ID === 'geom_data') {
                this.setGeomDataFeatures([]);
            }
        }
    }

    getBasemaps () {
        return basemaps;
    }

    getMap () {
        return map;
    }

    getMapBounds () {
        return mapBounds;
    }

    getGeomDataFeatures () {
        const geom = {};

        if (!('features' in geom_data)) {
            geom_data['type'] = "FeatureCollection";
            geom_data['features'] = [];
            geom_data['past_features'] = [];
        }

        if ('features' in geom_data && 'length' in geom_data['features']) {
            geom_data['features'].forEach(feature => {
                if ('properties' in feature  && 'fips' in feature.properties) {
                    const fips = feature.properties.fips;
                    geom[fips] = feature;
                } else if ('properties' in feature  && 'geoid' in feature.properties) {
                    const fips = feature.properties.geoid;
                    geom[fips] = feature;
                } else if ('properties' in feature && 'geoid_co' in feature.properties) {
                    const fips = feature.properties.geoid_co;
                    geom[fips] = feature;
                }
            })
        }

        return geom;
    }

    setGeomDataFeatures (features) {
        if (!!features && 'length' in features) {
            console.log("Update geom feature selection: ", features);

            if (!('features' in geom_data)) {
                geom_data['type'] = "FeatureCollection";
                geom_data['features'] = [];
                geom_data['past_features'] = [];
            }

            geom_data['features'].forEach(gf => {
                if (features.filter(feature => {
                    console.log(feature, gf);

                    if ('properties' in feature && 'fips' in feature.properties && 'fips' in gf.properties) {
                        return feature.properties.fips === gf.properties.fips;
                        
                    } else if ('properties' in feature && 'geoid' in feature.properties && 'geoid' in gf.properties) {
                        return feature.properties.geoid === gf.properties.geoid;
                        
                    } else if ('properties' in feature && 'geoid_co' in feature.properties && 'geoid_co' in gf.properties) {
                        console.log(feature.properties.geoid_co, gf.properties.geoid_co);
                        console.log(feature.properties.geoid_co === gf.properties.geoid_co);
                        return feature.properties.geoid_co === gf.properties.geoid_co;
                    }
                }).length < 1) {
                    console.log('past_features', gf);
                    geom_data['past_features'].push(gf);
                }
            });
            
            geom_data['features'] = features;
        }
    }

    changeBasemap (basemapIdOrURL) {
        const saveLayers = {};

        try {
            const basemap = basemaps.filter(bm => bm.id == basemapIdOrURL)[0];
            console.log("Set basemap", basemap);

            for (const l in map.layersById) try {
                saveLayers[l] = map.layersById[l];
                map.layersById[l].remove();
                delete map.layersById[l];
            } catch (e) {
                console.error(e);
            }

            map.setStyle('mapbox://styles/mapbox/' + basemap.id);

        } catch(e) {
            console.log('No basemap found, will try as URL: ', basemapIdOrURL)
            map.setStyle(basemapIdOrURL);
        } finally {

            for (const l in saveLayers) setTimeout(function () {
                try {
                    const layer = saveLayers[l]
                    if (typeof intrById[l] === 'function') {
                        layer.on('loaded', async (evt) => {
                            // console.log('LAYER LOADED: ', evt);
                            intrById[l](layer);
                        });
                    }
                    map.addLayerToMap(l, layer);
                } catch (e) {
                    console.error(e);
                }
            }, 533);
        }
    }
}
