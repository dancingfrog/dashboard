import { babel } from '@rollup/plugin-babel';
import commonjs from '@rollup/plugin-commonjs';
import copy from 'rollup-plugin-copy';
import livereload from 'rollup-plugin-livereload';
import postcss from 'rollup-plugin-postcss';
import postcssImport from 'postcss-import';
import postcssCssnext from 'postcss-cssnext';
import nodeResolve from '@rollup/plugin-node-resolve';
import replace from '@rollup/plugin-replace';
import resolve from '@rollup/plugin-node-resolve';
import svelte from 'rollup-plugin-svelte';
import { terser } from 'rollup-plugin-terser';
import dotenv from 'dotenv';
import { generate } from 'build-number-generator';

const version_file = "version.txt";

dotenv.config({ path: version_file });

const VERSION = generate({ version: process.env.VERSION_NUMBER.match(/(\d+\.\d+)/)[1] });

console.log("BUILD VERSION:", VERSION);

const production = !(process.argv.filter(arg => arg.match(/-w/) !== null).length > 0);

console.log("PRODUCTION:", production);

export default [{
	input: 'inst/src/main.js',
	output: {
		format: 'iife',
		file: 'inst/www/bundle.js',
		name: 'shiny_map_tool',
		sourcemap: !production
	},
	plugins: [
		replace({
			preventAssignment: true,
			"VERSION_NUMBER": VERSION
		}),

		babel({
			babelHelpers: 'runtime',
			babelrc: false,
			"plugins": [
				"@babel/plugin-transform-async-to-generator",
				"@babel/plugin-transform-regenerator",
				["@babel/plugin-transform-runtime", {
					"helpers": true,
					"regenerator": true
				}]
			],
			"presets": [
				"@babel/preset-env"
			],
			"exclude": "node_modules/**"
		}),

		commonjs({
			include: /node_modules/
		}),

		nodeResolve({
			mainFields: ["main"],
			moduleDirectories: [
				"node_modules/**",
				"inst/src/@deck.gl/bundle"
			]
		}),

		postcss({
			// inject?:
			// | boolean
			// | { [key: string]: any }
			// | ((cssVariableName: string, id: string) => string);
			// extract?: boolean | string;
			// onExtract?: onExtract;
			// modules?: boolean | { [key: string]: any };
			// extensions?: string[];
			// plugins?: any[];
			plugins: [ postcssImport, postcssCssnext ],
			// autoModules?: boolean;
			// namedExports?: boolean | ((id: string) => string);
			// minimize?: boolean | any;
			minimize: true,
			// parser?: string | FunctionType;
			// stringifier?: string | FunctionType;
			// syntax?: string | FunctionType;
			// exec?: boolean;
			// config?:
			// | boolean
			// | {
			// 	path: string;
			// 	ctx: any;
			// };
			// to?: string;
			// name?: any[] | any[][];
			// loaders?: any[];
			// onImport?: (id: string) => void;
			// use?: string[] | { [key in 'sass' | 'stylus' | 'less']: any };
			use: {
				'sass': {
					includePaths: [
						'./theme',
						'./node_modules'
					]
				}
			},
			// /**
			//  * @default: false
			//  **/
			// sourceMap?: boolean | 'inline';
			sourceMap: true
			// include?: Parameters<CreateFilter>[0];
			// exclude?: Parameters<CreateFilter>[1];
		}),

		// If you have external dependencies installed from
		// npm, you'll most likely need these plugins. In
		// some cases you'll need additional configuration -
		// consult the documentation for details:
		// https://github.com/rollup/plugins/tree/master/packages/commonjs
		resolve({
			browser: true,
			dedupe: ['svelte']
		}),

		copy({
			targets: [
				{ src: 'inst/src/data', dest: 'inst/www/' },
				{ src: 'inst/src/images', dest: 'inst/www/' },
				{ src: 'inst/src/styles/*', dest: 'inst/www/' },
				{ src: 'inst/src/@deck.gl/dist.min.js', dest: 'inst/www/@deck.gl/'},
				{ src: 'inst/src/@deck.gl/debug.min.js', dest: 'inst/www/@deck.gl/'},
				{ src: 'inst/src/@deck.gl/carto/dist.min.js', dest: 'inst/www/@deck.gl/carto'}
			]
		}),

		svelte({
			// enable run-time checks when not in production
			dev: !production,
			emitCss: true,
			// we'll extract any component CSS out into
			// a separate file - better for performance
			css: css => {
				css.write('bundle.css', true);
			}
		}),

		// Save version number
		!!production && save_version(VERSION),

		// In dev mode, call `npm run start` once
		// the bundle has been generated
		!production && serve(),

		// Watch the `public` directory and refresh the
		// browser on changes when not in production
		(!production || process.env['NODE_ENV'] !== "production") && livereload({ watch: 'inst/www', delay: 5333}),

		// If we're building for production (npm run build
		// instead of npm run dev), minify
		(production && process.env['NODE_ENV'] !== "development") && terser()
	],
	watch: {
		clearScreen: false
	}
}];

function save_version (version) {
	require('fs').writeFileSync(version_file, "VERSION_NUMBER=" + version);

	return {
		writeBundle() {
			setTimeout(console.log, 33, version);
		}
	}
}

function serve () {
	let started = false;

	return {
		writeBundle() {
			if (!started) {
				started = true;

				require('child_process').spawn('npm', ['run', 'start'], {
					stdio: ['ignore', 'inherit', 'inherit'],
					shell: true
				});
			}
		}
	};
}
